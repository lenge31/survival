# ubuntu 安装方式：
```
$ sudo apt install python3.7 python3-pip virtualenv
$ virtualenv --python=python3.7 --no-site-packages env
$ source env/bin/activate
$ pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple demjson
$ pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple deepmerge
$ pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple pytest
$ pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple pytest-repeat
$ pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple pygame
$ pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple requests
$ cd src && python main.py
```

