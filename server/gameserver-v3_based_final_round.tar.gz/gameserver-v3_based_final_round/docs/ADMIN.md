##### Admin guideline

1. launch frontend server
2. telnet <server ip> <admin port>, by default, admin port is 9528
3. Authenticate at first. send "AUTH <key>", and press <Return>. Valid key is in gm_default_config.json("admin_key" section)
4. When authentication passed, return <OK>. Otherwise, get an <ERROR>
5. "START" to start game
6. "LIST" to list all clients (online or offline)
7. "STATUS" to dump game status
8. "KILL" to kill server
9. "QUIT" to quit from server
