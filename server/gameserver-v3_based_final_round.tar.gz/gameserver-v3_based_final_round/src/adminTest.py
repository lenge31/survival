import socket
import threading
import time
import re
import random
from itertools import product



def admin():
    sco = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sco.connect(("127.0.0.1", 9528))

    sco.send(str.encode("AUTH 12345\n\r"), 9528)
    res = sco.recv(1024)


    mtime = 0
    while True:
        sco.send(str.encode("STATUS\n"), 9528)
        res = sco.recv(1024)
        print('admin status' + res.decode("utf8"))
        if res.decode().find("No game is running") >= 0:
            sco.send(str.encode("STOP\n"), 9528)
            print('admin stoping the game ')
            while True:
                sco.send(str.encode("LIST\n"), 9528)
                res = sco.recv(1024).decode("utf8")
                if res.count("state=Online") >=6:
                    break
                else:
                    mtime += 1
                    time.sleep(1)
            time.sleep(3)
            sco.send(str.encode("START\n"), 9528)
            res = sco.recv(1024)
            print('admin restart the game ' + res.decode())

        time.sleep(1)




def main():
    # for i in range(0, 8):
    #     t = threading.Thread(target=playerStart, args=(i,))
    #     t.start()
    #     time.sleep(0.5)

    time.sleep(1)
    t = threading.Thread(target=admin)
    t.start()




if __name__ == "__main__":
    main()
