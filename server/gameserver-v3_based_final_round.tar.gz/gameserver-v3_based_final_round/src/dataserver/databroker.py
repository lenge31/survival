import asyncio
import logging
import sys

logger = logging.getLogger(__name__)


class DataBroker(object):
    def __init__(self, consumer):
        self.consumer = consumer
        self.protocol = None
        self.read_fun = None
        self.fun_args = None
        self.exit = False

    def set_protocol(self, protocol):
        self.protocol = protocol

    def set_read_fun(self, read_fun):
        self.read_fun = read_fun

    def get_read_fun(self):
        return self.read_fun

    def stop(self):
        self.exit = True
        self.on_stop()

    def on_stop(self):
        pass

    async def monitor_data_input(self):
        loop = asyncio.get_running_loop()
        while not self.exit:
            res = await self.protocol.recv(loop)
            self.consumer.on_data(res)


class StdInDataBroker(DataBroker):
    def __init__(self, consumer):
        super(StdInDataBroker, self).__init__(consumer)
        self.set_read_fun(sys.stdin.buffer.read)
