from abc import ABC, abstractmethod


class IDataConsumer(ABC):
    @abstractmethod
    def on_data(self, data):
        raise NotImplementedError()
