import logging
import re
from struct import unpack

logger = logging.getLogger(__name__)

# From frontend to backend.
DATA_TYPE_PLAYER_NUM = 0x01
DATA_TYPE_CONTROL_DATA = 0x02
DATA_TYPE_EXIT = 0x99

# From backend to frontend.
DATA_TYPE_NOTIFY_MAP = 1
DATA_TYPE_GAME_OVER = 2

PAT_PLAYERS = re.compile(r'COUNT (\d+)')
CONTROL_DATA = re.compile(r'CONTROL ([asdwv X]+)')


class ProtocolV1(object):
    def __init__(self, data_broker):
        self.data_broker = data_broker

    async def recv(self, loop):
        read_f = self.data_broker.get_read_fun()
        logger.debug('before read header')
        _type = None
        size = None
        data = None
        header = ''
        while True:
            read = await loop.run_in_executor(None, read_f, 1)
            if read == b'\n':
                break
            else:
                header = header+read.decode('utf-8')

        m = PAT_PLAYERS.match(header)
        if m:
            data = int(m.group(1))
            _type = DATA_TYPE_PLAYER_NUM
            size = 4

        m = CONTROL_DATA.match(header)
        if m:
            data = str(m.group(1))
            _type = DATA_TYPE_CONTROL_DATA
            size = data.__len__()

        logger.debug('read header: %s', header)

        # if size > 0:
        #     data = await loop.run_in_executor(None, read_f, size)
        #     logger.debug('read data: %s', data)
        return _type, size, data
