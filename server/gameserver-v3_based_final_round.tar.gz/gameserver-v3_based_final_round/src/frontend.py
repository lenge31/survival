import argparse
import logging.config
import asyncio
import sys

from log import *
from settings import Settings
from version import GAME_VERSION
from frontend.classroom import ClassRoom

if __name__ == '__main__':
    # Configure logging with the default configurations.
    logging.config.dictConfig(LOGGING)
    logger.info('Game Server (%s)', GAME_VERSION)

    # Re-configure logging.
    logging.config.dictConfig(Settings.logging_config)


    parser = argparse.ArgumentParser(
        prog="python {}".format(sys.argv[0]),
        description='Thundersoft Technology Games.',
        epilog='Copyright (c) 2019-2019 All Rights Reserved by Thunder Software Technology Co.')
    parser.add_argument('--backend', dest='backend', action='store', default='normal', help='')
    parser.add_argument('--fake-auth', dest='fakeauth', action='store_true', default=False, help='')
    parser.add_argument('--headless', dest='headless', action='store_true', default=False, help='')
    parser.add_argument('--sidek', dest='sidek', action='store_true', default=False, help='')

    ARGS = parser.parse_args()
    Settings['fake_game'] = ARGS.backend
    Settings['sidek'] = ARGS.sidek

    if ARGS.headless:
        os.environ['SDL_VIDEODRIVER'] = 'dummy'

    loop = asyncio.get_event_loop()
    loop.set_debug(True)
    ClassRoom(no_auth=ARGS.fakeauth).run()
