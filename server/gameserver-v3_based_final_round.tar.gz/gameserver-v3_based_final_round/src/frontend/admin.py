from log import logger
import asyncio
import re
import time
import traceback


class Admin:
    PATTERN_AUTH = re.compile(r'(AUTH|auth)\s+([0-9a-zA-Z]+)')
    PATTERN_QUIT = re.compile(r'QUIT|quit')
    PATTERN_START = re.compile(r'START|start(\s+(.+))?')
    PATTERN_LIST = re.compile(r'LIST|list')
    PATTERN_STATUS = re.compile(r'STATUS|status')
    PATTERN_STOP = re.compile(r'STOP|stop')
    PATTERN_KILL = re.compile(r'KILL|kill')
    PATTERN_DUMP = re.compile(r'DUMP|dump\s([\/\.\w\d]+)')

    def __init__(self, match, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        self.match = match
        self.reader = reader
        self.writer = writer

    async def main_loop_run(self):
        try:
            while True:
                data = await self.reader.readline()
                if not data:
                    break
                message = data.decode().strip()
                result, response = self.on_message(message)
                response += '\r\n'
                self.writer.write(response.encode())
                if not result:
                    break

            print("Close the connection")
            self.writer.close()
        except Exception:
            logger.error(traceback.format_exc())

    def on_message(self, message: str):
        logger.debug(f'Got admin message:{message}')
        m = self.PATTERN_AUTH.match(message)
        if m:
            key = m.groups()[1]
            return self.match.auth_admin(key, self)

        m = self.PATTERN_QUIT.match(message)
        if m:
            return self.disconnect()

        if not self.match.check_admin_auth(self):
            return True, 'ERROR: Unauthorized admin'

        m = self.PATTERN_START.match(message)
        if m:
            return self.match.start_game(m.groups()[1], self)

        m = self.PATTERN_LIST.match(message)
        if m:
            return self.match.list_clients(self)

        m = self.PATTERN_STATUS.match(message)
        if m:
            return self.match.status(self)

        m = self.PATTERN_STOP.match(message)
        if m:
            return self.match.stop_game(self)

        m = self.PATTERN_KILL.match(message)
        if m:
            return self.match.kill_room(self)

        m = self.PATTERN_DUMP.match(message)
        if m:
            self.print_task_stack(m.groups()[0])
            return True, 'OK'

        return True, 'ERROR: UNSUPPORTED COMMAND'

    def send_message(self, message):
        self.writer.write(message.encode())

    def disconnect(self):
        return False, 'OK'

    @staticmethod
    def print_task_stack(filename):
        with open(filename, 'w+') as dest:
            print('Begin to dump task stacks\n', file=dest)
            tasks = asyncio.all_tasks()
            for task in tasks:
                task.print_stack(file=dest)
                print('-' * 40, file=dest)
            print('End\n', file=dest)


class AdminListener:
    def __init__(self, match, ip, port):
        self.ip = ip
        self.port = port
        self.match = match
        self.server = None

    def close(self):
        if self.server:
            self.server.close()

    def on_connected(self, reader, writer):
        admin = Admin(self.match, reader, writer)
        asyncio.create_task(admin.main_loop_run())
        # asyncio.create_task(print_task())

    def start(self, loop):
        self.server = loop.run_until_complete(asyncio.start_server(
            self.on_connected, self.ip, self.port))

        addr = self.server.sockets[0].getsockname()
        logger.info(f'Admin serving on {addr}:{self.port}')
