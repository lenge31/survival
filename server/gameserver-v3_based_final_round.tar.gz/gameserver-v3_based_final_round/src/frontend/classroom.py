from frontend.client import *
from frontend.admin import *
from frontend.game import GameLauncher
from settings import Settings
import io, time, re
from datetime import datetime
import asyncio


class ClassRoom(Match):
    PATTERN_DATE_TIME = re.compile(r'(\d{4}-\d{2}-\d{2}\s+)?(\d{1,2}\:\d{2})(\:\d{2})?\s+(\d+)\s+(\d+)')
    PATTERN_COUNT_ONLY = re.compile(r'now\s+(\d+)\s+(\d+)')

    def __init__(self, no_auth=False):
        super().__init__()
        self.no_auth = no_auth
        settings = Settings['server']
        ip = settings['ip']
        port = settings['port']
        admin_port = settings['admin_port']

        self.admin_listener = AdminListener(self, ip, admin_port)
        self.client_listener = ClientListener(self, ip, port)
        self.admins = set()
        self.clients = {}

        self.main_task = None
        self.start_round_parameters = None
        self.start_round_event = asyncio.Event()
        self.is_server_aborted = False
        self.is_round_cancelled = False
        self.is_round_cancelled_event = asyncio.Event()

        self.game_task = None
        self.is_game_running = False
        self.loop = asyncio.get_event_loop()

        self.listener_status=False

    def run(self):
        """
        Start backend socket server and wait for client to connect.
        """
        self.client_listener.start(self.loop)
        # self.listener_status = True
        self.admin_listener.start(self.loop)
        self.loop.run_until_complete(self.main_proc())
        self.log_message('Server stopped')
        # self.main_task = asyncio.create_task()
        # self.loop.run_forever()

    def auth_admin(self, key, admin):
        if key in Settings['admin_keys']:
            self.admins.add(admin)
            return True, 'OK'
        return True, 'ERROR: Unauthorized admin'

    def check_admin_auth(self, admin):
        return self.no_auth or admin in self.admins

    def start_game(self, arguments, admin):
        # if(self.listener_status == False):
        #     self.client_listener.start(self.loop)
        if self.game_task:
            logger.error('Game is launched. Cannot launch it again.')
            return True, 'ERROR: Cannot launch game when it is already running'

        current_time = time.time()
        start_time, time_for_round, repeats = (current_time, 600, 10)
        try:
            if arguments:
                m = self.PATTERN_COUNT_ONLY.match(arguments)
                if m:
                    match_group = m.groups()
                    time_for_round = int(match_group[0])
                    repeats = int(match_group[1])
                else:
                    m = self.PATTERN_DATE_TIME.match(arguments)
                    if not m:
                        return True, 'ERROR: Wrong parameters. ' \
                                     'Input \'yyyy-mm-dd HH:MM sec rep\' or \'HH:MM sec rep\'. Second part is ignored'
                    match_group = m.groups()
                    date = match_group[0] if match_group[0] else datetime.today().strftime('%Y-%m-%d')

                    time_string = ' '.join((date, match_group[1]))
                    start_time = time.mktime(time.strptime(time_string, '%Y-%m-%d %H:%M'))

                    if start_time < current_time:
                        return True, 'ERROR: Time expired.'
                    time_for_round = int(match_group[3])
                    repeats = int(match_group[4])
        except Exception:
            return True, 'ERROR: Wrong parameters. ' \
                         'Input \'yyyy-mm-dd HH:MM sec rep\' or \'HH:MM sec rep\'. Second part is ignored'

        logger.info('To start round.')
        self.is_round_cancelled = False
        self.start_round_parameters = (start_time, time_for_round, repeats)
        self.start_round_event.set()
        return True, 'OK'

    def stop_game(self, admin):
        self._cancel_round()
        # self.client_listener.close()
        # self.listener_status = False
        return True, 'OK'

    def kill_room(self, admin):
        # Stop listening to block new connections
        self.admin_listener.close()
        self.client_listener.close()

        self._stop_room()
        return False, 'OK'

    def on_kill_done(self):
        self.loop.stop()

    def list_clients(self, admin):
        client_list = []
        for client in self.clients.values():
            client_info = f'{client.key} - {client}: state={client.state.name}'
            if client.old_client:
                old_client = client.old_client
                client_info += f' old={old_client}:{old_client.state.name}'
            client_list.append(client_info)
        client_list.append('OK')
        return True, '\n'.join(client_list)

    def status(self, admin):
        output = io.StringIO()
        if self.start_round_parameters:
            start_time = time.ctime(self.start_round_parameters[0])
            second_per_game = self.start_round_parameters[1]
            repeat = self.start_round_parameters[2]
            output.write(f'Scheduled round: '
                         f'start at [{start_time}] {second_per_game}s per game, repeat for {repeat} times\n')
        if not self.is_game_running:
            output.write('No game is running.\n')
        else:
            output.write('Game status:\n')
            for game in self.launcher.games:
                output.write(f' - Game {game}: {game.status}\n')
                for client in game.players:
                    output.write(f'  - Player {client.game_no}: {client.status}\n')

        output.write('OK')
        contents = output.getvalue()
        output.close()
        return True, contents

    def new_client(self, client):
        # Deal with current logged in client
        key = client.key

        if key in self.clients:
            old_client = self.clients[key]
            self.log_message(f'{old_client} is already logged in. Kick it off')
            old_client.close()
            if self.is_game_running:
                client.old_client = old_client

        # Add new client to map
        self.clients[key] = client
        self.log_message(f'New client {client} is in')

    def __auth_key(self, key):
        if self.no_auth:
            return True
        return key in Settings['auth_keys']

    def auth_key(self, client):
        # Check if key in authorized list
        if not self.__auth_key(client.key):
            self.log_message(f'New client {client} is rejected')
            return False
        self.new_client(client)
        return True

    async def main_proc(self):
        try:
            while not self.is_server_aborted:
                self.start_round_event.clear()
                await self.start_round_event.wait()
                if self.start_round_parameters:
                    self.game_task = asyncio.create_task(self.auto_launch_game())
                    await self.game_task
                    self.game_task = None
                    self.start_round_parameters = None
                    self.on_round_over()
            logger.warn('Server is aborted')
        except Exception:
            logger.error(traceback.format_exc())
        self.on_kill_done()

    async def auto_launch_game(self):
        start_time, time_for_round, repeats = self.start_round_parameters
        try:
            # launch games for {repeats} times
            repeats = 10
            if repeats == -1:
                repeats = 10000

            for i in range(repeats):
                # Clear all disconnected clients
                for client in self.clients.values():
                    if client.old_client:
                        client.old_client = None

                # wait for time reaches
                time_str = time.ctime(start_time)
                self.log_message(f'Try to start game({i + 1} of {repeats}) at {time_str}')
                while start_time > time.time():
                    sleep_seconds = start_time - time.time()
                    self.is_round_cancelled_event.clear()
                    try:
                        logger.info('Schedule for next launching')
                        await asyncio.wait_for(self.is_round_cancelled_event.wait(), sleep_seconds)
                        logger.info(f'Awaken up by someone. I am angry! aborted = {self.is_round_cancelled}')
                        break
                    except asyncio.TimeoutError:
                        logger.info('Time is coming! Let\'s go!')
                        pass

                if self.is_round_cancelled:
                    self.log_message('Round is aborted')
                    break

                self.is_game_running = True
                self.launcher = GameLauncher(self)

                alive_clients = [client for client in self.clients.values() if client.is_online]

                if len(alive_clients) > 0:
                    await self.launcher.run_game(alive_clients)
                    self.log_message(f'Game is over.')
                else:
                    self.log_message('No player attended. Skip this round')

                self.is_game_running = False
                del self.launcher

                # Shift time to next round
                start_time += time_for_round
        except Exception:
            logger.error(traceback.format_exc())
        self.start_round_parameters = None

    def _cancel_round(self):
        self.log_message('Request to cancel current round')
        if self.start_round_event.is_set():
            logger.warn(f'An active round is running. Wait for it to end.')
            self.is_round_cancelled = True
            self.is_round_cancelled_event.set()

    def _abort_round(self):
        self.log_message('Request to abort current round')
        if self.start_round_event.is_set():
            logger.warn('An active round is running. Wait for it to end.')
            self.is_round_cancelled = True
            self.is_round_cancelled_event.set()
            if self.is_game_running:
                logger.info('Kill all backend')
                self.launcher.kill()
            logger.info('All backend exited')

    def _stop_room(self):
        try:
            self.log_message('Request to stop server')
            self._abort_round()
            self.is_server_aborted = True
            self.start_round_parameters = None
            self.start_round_event.set()
        except Exception:
            logger.error(traceback.format_exc())

    def log_message(self, message):
        logger.info(message)
        message += '\n'
        for admin in self.admins:
            admin.send_message(message=message)

    def on_client_state_changed(self, client: Client, old_state: ClientState, new_state: ClientState):
        message = f'Client {client} changed from {old_state.name} to {new_state.name}'
        self.log_message(message)

    def on_game_started(self, game):
        message = f'Game {game} started.'
        self.log_message(message)

    def on_game_stopped(self, game):
        message = f'Game {game} stopped.'
        self.log_message(message)

    def on_round_over(self):
        for client in self.clients.values():
            if client.is_online:
                client.write_string('[ROUNDOVER]')
