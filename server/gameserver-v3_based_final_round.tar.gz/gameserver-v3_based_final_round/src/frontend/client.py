import socket
import time
import random

from frontend.match import *
from utils.mqueue import *

from settings import Settings

key_by_index =  ["NULL" for _ in range(Settings['max_clients'])]
game_type = "T"
class Client(MessageQueue):
    MESSAGE_END_CHAR = b')'

    def __init__(self, match, transport):
        super().__init__()
        self._state = ClientState.NotAuthenticated
        self.match = match
        self.map_size = 0

        self.game_no = -1
        self.game = None

        self.key = ""
        self.name = ""

        self.transport = transport
        self.buffer = bytearray()
        self._control_char = bytearray(2)

        self.active_time = time.monotonic()
        self.main_task = asyncio.create_task(self.run())

        self.token = random.randint(0, 255)
        self.old_client = None

    def __str__(self):
        return f'Client-<{self.key[:6]}-{self.token}>)'

    @property
    def status(self):
        return f'{self} - {self.state.name}, {self.control_chars}'

    @property
    def writer(self):
        return self.transport

    @property
    def state(self):
        return self._state

    @state.setter
    def state(self, new_state):
        old_state = self._state
        if self.game:
            self.game.on_player_state_changed(self, old_state, new_state)
        if self.match:
            self.match.on_client_state_changed(self, old_state, new_state)
        self._state = new_state

    def close(self):
        self.transport.close()

    def set_login(self, login):
        self.state = ClientState.Online

    def parse_received_data(self, data: bytes):
        self.buffer += data
        self.buffer = self.buffer.replace(b'\r\n', b'')
        while True:
            found = self.buffer.partition(self.MESSAGE_END_CHAR)
            if found[1]:
                quoted_data = found[0][1:]
                logger.debug(f'Get data from client {quoted_data}')
                self.buffer = found[2]
                self.push_message(Message(sender=self, type=1, data=quoted_data.decode()))
            else:
                break

    async def run(self):
        try:
            self.state = await self.login()
            if self.state != ClientState.Online:
                return False

            while True:
                logger.info('{self} Wait for game')
                self.state = await self.wait_for_game()
                if self.state != ClientState.NotReady:
                    return False

                try:
                    logger.info('{self} Wait for ready')
                    await asyncio.wait_for(self.wait_for_ready(), timeout=5.0 * debug_times)
                except asyncio.TimeoutError:
                    pass

                if self.state in (ClientState.Online, ClientState.NotReady):
                    self.state = ClientState.Online
                    logger.error('Client not respond within 5 seconds. Skip this game')
                    self.game.push_message(Message(sender=self, type='TIMEOUT', data=self))
                    self.write_string('[TIMEOUT]')
                    continue
                elif self.state == ClientState.Offline:
                    return False

                logger.info(f'{self} Play Game')
                self.state = await self.play_game()
                logger.info(f'{self} Play Game over')
                if self.state == ClientState.Offline:
                    return False
                self.state = await self.wait_for_quit()
                logger.info(f'{self} Client quit done')
        except asyncio.TimeoutError:
            logger.error(traceback.format_exc())
        except Exception:
            logger.error(traceback.format_exc())

    async def login(self):
        try:
            for i in range(5):
                message = await self.fetch_message()

                if message.is_closing:
                    logger.warn('I am closed.')
                    return ClientState.NotAuthenticated

                self.key = message.data
                if message.sender == self and self.match.auth_key(self):
                    self.write_string('[OK]')
                    return ClientState.Online
                else:
                    self.write_string('[ERROR]')
        except Exception:
            logger.error(traceback.format_exc())
        return ClientState.NotAuthenticated

    async def wait_for_game(self):
        try:
            logger.info(f'Wait for game start {self}')
            while True:
                try:
                    message = await asyncio.wait_for(self.fetch_message(), timeout=10.0 * debug_times)
                except asyncio.TimeoutError:
                    logger.error('Client did not send heartbeat in 10 seconds. Kick it off!')
                    self.close()
                    return ClientState.Offline

                if message.is_closing:
                    return ClientState.Offline
                elif message.sender == self:
                    if message.data == 'H':
                        logger.info(f'Heartbeat {self}')
                        self.write_string('[OK]')
                        self.active_time = time.monotonic()
                    else:
                        self.write_string('[ERROR]')
                elif message.sender == self.game and message.type == 'START':
                    self.map_size = message.data
                    key_by_index[self.game_no] = self.key
                    logger.info(f'Tell client game is staring {self} {self.game_no} {self.map_size}')
                    self.write_string(f'[START {self.game_no} {self.map_size}]')
                    break
            return ClientState.NotReady
        except Exception:
            logger.error(traceback.format_exc())
        return ClientState.Offline

    async def wait_for_ready(self):
        try:
            logger.info(f'Wait for client ready {self}')
            while True:
                message = await asyncio.wait_for(self.fetch_message(), 5.0 * debug_times)
                if message.is_closing:
                    self.state = ClientState.Offline
                    return
                if message.data == 'READY':
                    logger.info(f'Client is ready {self}')
                    self.game.push_message(Message(sender=self, type='READY', data=self))
                    self.state = ClientState.Active
                    return
        except asyncio.TimeoutError:
            logger.error(f'Client {self} is timed out. Not to wait it more.')
            self.state = ClientState.Online
        except Exception:
            logger.error(traceback.format_exc())
        self.state = ClientState.Online

    async def play_game(self):
        try:
            while True:
                logger.info(f'Wait for map data {self}')
                message = await self.fetch_message()
                sender = message.sender
                type = message.type

                if message.is_closing:
                    return ClientState.Offline

                # Message from backend or game controller
                if sender == self.game:
                    if type == 'GAMEOVER':
                        return ClientState.Online

                # Message from client
                if sender == self:
                    data = message.data.encode()
                    logger.info(f'Control message {self}: {data}')
                    if len(data) < 4:
                        self.write_string('[ERROR]')
                        continue
                    token = data[:2]
                    direction = data[2:3]
                    fired = data[3:4]
                    if self.on_control_received(token, direction, fired):
                        self.write_string('[OK]')
                    else:
                        self.write_string('[ERROR]')
        except Exception:
            logger.error(traceback.format_exc())
        return ClientState.Offline

    def on_map_status(self, message):
        if self.is_active:
            logger.info(f'Get map data {self}')
            self.write_message(message)
            self._control_char = b'  '

    def on_game_over(self, data):
        if self.is_active:
            self.write_message(f'[GAMEOVER {data}]'.encode())
            self.push_message(Message(sender=self.game, type='GAMEOVER'))

    def on_control_received(self, token, direction, fired):
        # Check if control is already received
        if self._control_char != b'  ':
            return False

        # Check if control char is valid
        if direction not in (b'w', b'a', b's', b'd', b' ') or fired not in (b'v', b' '):
            logger.error(f'Wrong control {direction}, {fired}')
            return False

        if not self.game.on_control_received(self.game_no, token, direction, fired):
            return False

        self._control_char = direction + fired
        return True

    async def wait_for_quit(self):
        try:
            logger.info(f'Wait for client quit {self}')
            while True:
                message = await asyncio.wait_for(self.fetch_message(), 5.0 * debug_times)
                if message.is_closing:
                    return ClientState.Offline

                if message.data == 'QUIT':
                    self.write_message(b'[OK]')
                    return ClientState.Online
                else:
                    self.write_message(b'[ERROR]')

        except asyncio.TimeoutError:
            logger.error(f'Client {self} is timed out. Not to wait it more.')
            return ClientState.Online
        except Exception:
            logger.error(traceback.format_exc())
        return ClientState.Online

    def on_disconnect(self):
        self.state = ClientState.Offline
        self.push_message(CLOSE_MESSAGE)
        # self.main_task.cancel()

    def set_game(self, game, game_no):
        self.game = game
        self.game_no = game_no

    @property
    def control_chars(self):
        if self.is_active:
            return self._control_char
        else:
            return b'XX'

    @property
    def is_active(self):
        return self.state == ClientState.Active

    @property
    def is_online(self):
        return self.state in (ClientState.Online, ClientState.Active)


class ClientProtocol(asyncio.Protocol):
    def __init__(self, match: Match):
        self.client = None
        self.match = match

    def connection_made(self, transport) -> None:
        self.client = Client(self.match, transport)

    def connection_lost(self, exc) -> None:
        self.client.on_disconnect()

    def data_received(self, data: bytes) -> None:
        self.client.parse_received_data(data=data)


class ClientListener:
    def __init__(self, match, ip, port):
        self.match = match
        self.ip = ip
        self.port = port
        self.server = None

    def close(self):
        if self.server:
            self.server.close()

    def start(self, loop):
        self.server = loop.run_until_complete(
            loop.create_server(protocol_factory=lambda: ClientProtocol(self.match),
                               host=self.ip, port=self.port, family=socket.AF_INET,
                               reuse_address=True))
        addr = self.server.sockets[0].getsockname()
        logger.info(f'Room serving on {addr}:{self.port}')
