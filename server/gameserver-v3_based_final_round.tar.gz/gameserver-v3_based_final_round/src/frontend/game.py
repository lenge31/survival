import csv
import datetime
import io
import random
import re
import sys
from asyncio import subprocess
from operator import attrgetter
from struct import *

import requests

from frontend.match import ClientState, GameState, debug_times
from settings import Settings
from utils.mqueue import *
from version import GAME_VERSION


class PlayerRank:
    POINTS = (20, 15, 10, 7, 5, 3, 2, 1, 0, 0, 0, 0, 0, 0)

    def __init__(self, lifetime, score, player):
        self.lifetime = lifetime
        self.score = score
        self.player = player

    @staticmethod
    def point(my_rank):
        if my_rank < len(PlayerRank.POINTS):
            return PlayerRank.POINTS[my_rank]
        return 0


class GameProtocol(asyncio.SubprocessProtocol):
    def __init__(self, game):
        self.game = game

    def pipe_data_received(self, fd, data):
        logger.debug(f'Get data from backend {data}')
        self.game.parse_backend_data(data)

    def process_exited(self):
        self.game.on_game_quit()


class Game(MessageQueue):
    MAP_SIZE = Settings['map_size']
    MAP_DATA_SIZE = MAP_SIZE * MAP_SIZE

    def __init__(self, match, game_index, player_count):
        super().__init__()
        self.match = match
        self.state = GameState.Inited
        self.game_index = game_index
        self.token = bytearray(2)
        self.map_size = Settings['map_size']
        self.players = []
        self.buffer = bytearray()
        self._writer = None
        self.protocol = None
        self.current_round = 0
        self.task = None
        self.read_task = None
        self.player_control_event = asyncio.Event()
        self.fake_event = asyncio.Event()
        self.config_sidek = Settings['sidek']
        self.create_time = datetime.datetime.now().strftime('%Y%m%d%H%M%S')

    def __str__(self):
        return f'Game-{self.create_time}-{self.game_index}'

    @property
    def status(self):
        return f'State:{self.state.name} Round:{self.current_round}'

    @property
    def player_count(self):
        return len(self.players)

    @property
    def writer(self):
        return self._writer

    def add_player(self, player, index):
        self.players.append(player)
        player.set_game(self, index)

    async def read_proc_message(self, sub_process):
        try:
            PAT_MESSAGE = re.compile(r'(\w+) (.+)')
            while True:
                line = await sub_process.stdout.readline()

                if not line:
                    self.push_message(CLOSE_MESSAGE)
                    break

                message = line.decode().strip()
                m = PAT_MESSAGE.match(message)
                if not m:
                    logger.error(f'Malformed message')
                    continue
                logger.debug(f'Get message from backend {message}')
                self.push_message(Message(sender=self, type=m.group(1), data=m.group(2)))
                if m.group(1) == 'GAMEOVER':
                    break
        except Exception:
            logger.error(traceback.format_exc())
            self.push_message(CLOSE_MESSAGE)
        return True

    async def fake_proc_message(self):
        # map_data = '0' * 225
        map_data = '0' * 625
        location_data = '1 2 3 4 5 6 7 8 9 10 11'
        score_data = '1 2 3 4 5 6 7 8 9 10 11'
        for i in range(60):
            await self.fake_event.wait()
            self.fake_event.clear()
            self.push_message(Message(sender=self, type='MAP', data=map_data))
            self.push_message(Message(sender=self, type='LOCATION', data=location_data))
            self.push_message(Message(sender=self, type='SCORE', data=score_data))
        self.push_message(Message(sender=self, type='GAMEOVER', data=score_data))
        self.on_game_quit()
        return True

    def parse_backend_data(self, data):
        self.buffer += data
        type, size = unpack('ii', self.buffer[:8])
        if len(self.buffer) < 8 + size:
            return

        real_data = self.buffer[8:size + 8]
        self.buffer = self.buffer[size + 8:]
        self.push_message(Message(sender=self, type=type, data=real_data))

    @staticmethod
    def make_buffer_for_backend(type, data):
        return f'{type} {data}\r\n'.encode()

    def send_message_to_backend(self, type, data):
        self.write_message(self.make_buffer_for_backend(type, data))

    def send_control(self):
        self.send_message_to_backend('CONTROL', self.control_chars.decode())

    def run(self):
        # Start game activity
        self.task = asyncio.create_task(self.__run_game())
        return self.task

    async def __run_game(self):
        try:
            result = await self.prepare_game()

            if not result:
                logger.warn('No one in. Skip this game!')
                self.state = GameState.GameOver
                return

            logger.info(f'Game<{self}> is started')
            self.state = GameState.Running
            self.match.on_game_started(self)
            self.send_message_to_backend('COUNT', self.player_count)
            self.fake_event.set()

            self.is_running = True
            self.current_round = 0

            while self.is_running:
                logger.info(f'{self} Wait for Map data')
                try:
                    map_data = await asyncio.wait_for(self.wait_for_map_data(), 8.0)
                except asyncio.TimeoutError:
                    logger.warn(f'Backend not response for 3s. Force quit')
                    break

                if not map_data:
                    break
                self.on_map_status(map_data)

                try:
                    await asyncio.wait_for(self.player_control_event.wait(), 3.0)
                except asyncio.TimeoutError:
                    logger.warn(f'Someone did not send control in time')
                self.send_control()
                self.fake_event.set()

            self.state = GameState.GameOver
            await self.wait_for_game_quit()
            self.match.on_game_stopped(self)
            logger.info(f'Game{self} is over')
            self.state = GameState.GameQuited
        except Exception:
            logger.error(traceback.format_exc())

    @staticmethod
    def gen_token_char():
        return random.randint(48, 126)

    async def wait_for_map_data(self):
        try:
            map_data = None
            location_data = None
            score_data = None
            self.token[0] = self.gen_token_char()
            self.token[1] = self.gen_token_char()

            while True:
                logger.info(f'{self} Wait for Map data')
                message = await self.fetch_message()
                logger.info(f'{self} Map data arrived {message.type}')

                if message.is_closing:
                    logger.warn('I am closed.')
                    return False

                if message.type == 'MAP':
                    map_data = b' '.join([b'MAP', self.token, message.data.encode()])
                elif message.type == 'LOCATION':
                    location_data = b' '.join([b'LOCATION', self.token, message.data.encode()])
                elif message.type == 'SCORE':
                    score_data = b' '.join([b'SCORE', self.token, message.data.encode()])
                elif message.type == 'GAMEOVER':

                    self.on_game_over(message.data)
                    return False
                elif message.type == 'QUIT':
                    return False

                if map_data and location_data and score_data:
                    self.current_round += 1
                    return map_data, location_data, score_data
        except Exception:
            logger.error(traceback.format_exc())

    async def prepare_game(self):
        # Call all player to join the game, and launch game in parallel
        ping_players_task = asyncio.create_task(self.ping_players())
        player_ready = await ping_players_task

        if player_ready == 0:
            logger.warn('No player is ready. skip this game.')
            return False

        if Settings['fake_game'] == 'fake':
            launch_game_task = asyncio.create_task(self.launch_fake_game())
        else:
            launch_game_task = asyncio.create_task(self.launch_game())

        await launch_game_task
        return True

    # Send [START] to every players
    async def ping_players(self):
        self.state = GameState.PingPlayers

        logger.info(f'Send [START] to {len(self.players)} players')
        for player in self.players:
            player.push_message(Message(sender=self, type='START', data=self.map_size))

        logger.info(f'{self} Wait for all player ready')
        result, player_ready = await self.wait_for_player_ready()
        if not result:
            return
        logger.info(f'{self} Wait for all player ready done')

    def count_ready_players(self):
        player_ready = 0
        for player in self.players:
            if player.state != ClientState.NotReady:
                player_ready += 1
        return player_ready

    async def wait_for_player_ready(self):
        player_ready = 0
        try:
            while player_ready < self.player_count:
                logger.debug('wait for player ready.'
                             f'count={self.player_count} ready={player_ready}')

                message = await asyncio.wait_for(self.fetch_message(), 5.0 * debug_times)

                if message.is_closing:
                    logger.warn('I am closed.')
                    return False, 0

                elif message.type in ('READY', 'TIMEOUT'):
                    player_ready = self.count_ready_players()
                    logger.debug(f'Ready={player_ready} total={self.player_count}')
            logger.debug(f'All players are ready or out. ready={player_ready} total={self.player_count}')
        except asyncio.TimeoutError:
            return True, player_ready
        except Exception:
            logger.error(traceback.format_exc())
            return False, 0
        return True, player_ready

    async def launch_game(self):
        self.state = GameState.LoadingGame
        try:
            # Start game process
            loop = asyncio.get_running_loop()
            executable = sys.executable
            if Settings['fake_game'] == 'test':
                arguments = '../tests/test_game.py'
            else:
                arguments = 'main.py'

            logger.info(f'Launch game {self.game_index}')
            self.sub_process = await asyncio.create_subprocess_exec(
                executable, arguments, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=None)

            self._writer = self.sub_process.stdin
            self.read_task = asyncio.create_task(self.read_proc_message(self.sub_process))

        except Exception:
            logger.error(traceback.format_exc())

    async def launch_fake_game(self):
        self.state = GameState.LoadingGame
        try:
            self._writer = io.StringIO()
            self.fake_event.clear()
            self.read_task = asyncio.create_task(self.fake_proc_message())
        except Exception:
            logger.error(traceback.format_exc())

    def on_map_status(self, data):
        logger.info(f'Send map data to clients')

        self.player_control_event.clear()
        self.current_round += 1

        map_data = data[0]
        location_data = data[1]
        score_data = data[2]
        message = b'[' + map_data + b'][' + location_data + b'][' + score_data + b']'

        for player in self.players:
            player.on_map_status(message)

    def _calculate_ranks(self, numbers):
        scores = numbers[:self.player_count]
        lifetimes = numbers[self.player_count:]
        if len(scores) < self.player_count or len(lifetimes) < self.player_count:
            logger.error('No enough numbers from gameover message')
            return []

        rank_list = []
        for i, player in enumerate(self.players):
            rank_list.append(PlayerRank(lifetimes[i], scores[i], player))

        points = []
        previous_player = PlayerRank(-1, -1, None)
        previous_point = 0
        for i, rank in enumerate(sorted(rank_list, key=attrgetter('lifetime', 'score'), reverse=True)):
            logger.info(f'Rank {rank.player}, {rank.lifetime}, {rank.score}')
            point = PlayerRank.point(i)
            if rank.lifetime == previous_player.lifetime and rank.score == previous_player.score:
                point = previous_point
            points.append((rank.player, point))
            previous_point = point
            previous_player = rank
        return points

    def saveas_points(self, points):
        for player, score in points:
            try:
                with open('score.csv', 'a', newline='') as csvfile:
                    spamwriter = csv.writer(csvfile, delimiter=',',
                                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
                    spamwriter.writerow([player.key, score, GAME_VERSION, self.create_time])
            except Exception as ex:
                logger.exception("saveas score fail, exception: %s", ex)

    def upload_points(self, points):
        for player, score in points:
            data = {
                '1s8He': player.key,  # team_name,
                'sd9ln': score,  # score
                '9iDsw': GAME_VERSION,  # game version
            }
            try:
                r = requests.post('https://thunderworld.thundersoft.com/api/team/log/insertFinal', data, timeout=10)
                logger.info('upload score result: %s', r.text)
            except Exception as ex:
                logger.exception("upload score fail, exception: %s", ex)

    def on_game_over(self, data):
        for player in self.players:
            player.on_game_over(data=data)
        self.send_message_to_backend('EXITED', 'Thank you!')

        # Upload scores when not in test mode
        if not self.config_sidek:
            numbers = [int(digits) for digits in data.split()]
            points = self._calculate_ranks(numbers)
            self.saveas_points(points)

    def on_game_quit(self):
        logger(f'Game {self} exited')
        self.push_message(CLOSE_MESSAGE)

    async def wait_for_game_quit(self, kill=False):
        if kill:
            self.sub_process.terminate()
        try:
            for i in range(5):
                try:
                    await asyncio.wait_for(self.sub_process.wait(), 1.0)
                    return True
                except asyncio.TimeoutError:
                    self.sub_process.terminate()
            for i in range(5):
                try:
                    await asyncio.wait_for(self.sub_process.wait(), 1.0)
                    return True
                except asyncio.TimeoutError:
                    self.sub_process.kill()
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.error(traceback.format_exc())

    def on_control_received(self, game_no, token, direction, fired):
        # Check if token matches
        if token != self.token and token != b'pw':
            logger.error(f'Token mismatched {token}, {self.token}')
            return False

        for player in self.players:
            if player.control_chars == b'  ':
                return True
        self.send_control()
        return True

    @property
    def is_alive(self):
        return not self.config_sidek or self.current_round > 3

    @property
    def control_chars(self):
        control_chars = bytearray()
        for player in self.players:
            control_chars += player.control_chars if self.is_alive else b'XX'
        return control_chars

    def on_player_state_changed(self, player, old_state: ClientState, new_state: ClientState):
        logger.info(f'Player {player} changed from {old_state.name} to {new_state.name}')

    async def kill(self):
        await self.wait_for_game_quit(kill=True)


class GameLauncher:
    group_members = Settings['max_clients']

    def __init__(self, match):
        self.player_count = 0
        self.players = []
        self.games = []
        self.match = match

    async def run_game(self, players):
        try:
            self.players = players
            self.player_count = len(players)
            if (self.player_count == 0):
                logger.error('No player attended. Skip this round')
                return
            self.games = self.__assign_player_to_game(self.player_count)
            tasks = []

            for game in self.games:
                tasks.append(game.run())
            await asyncio.gather(*tasks)
        except Exception:
            logger.error(traceback.format_exc())

    def kill(self):
        tasks = []
        for game in self.games:
            tasks.append(asyncio.create_task(game.kill()))
        return tasks

    def __assign_player_to_game(self, player_count):
        player_copy = list(self.players)
        games = []
        groups, player_per_group = self.__calc_groups(player_count, self.group_members)

        for game_index in range(groups):
            games.append(Game(self.match, game_index, player_per_group))

        for i in range(self.player_count):
            if len(player_copy) == 0:
                break
            game = games[i % groups]
            index = random.randint(0, len(player_copy) - 1)
            player = player_copy[index]
            game.add_player(player, i // groups)
            player_copy.remove(player)

        return games

    @staticmethod
    def __calc_groups(player_count, max_player_per_group):
        guess_group = (player_count + max_player_per_group - 1) // max_player_per_group
        for group_count in range(guess_group, 100):
            player_per_group, remain = divmod(player_count, group_count)
            if remain == 0:
                return group_count, player_per_group
            if remain < group_count:
                return group_count, player_per_group + 1
