from enum import IntEnum

debug_times = 5.0


class ClientState(IntEnum):
    NotAuthenticated = 0,  # Connected but not pass key auth
    Offline = 1,  # Disconnected
    Online = 2,  # Connected and waiting for game
    NotReady = 3,  # Game started and wait for (READY)
    Active = 4,  # In game

    @property
    def is_online(self):
        return self in (ClientState.Online, ClientState.Active)


class GameState(IntEnum):
    Inited = 0,  # Init state
    PingPlayers = 1,  # Pinging players
    LoadingGame = 2,  # Loading game
    Running = 3,  # Game is running
    GameOver = 4,  # Game is over
    GameQuited = 5,  # Game is over


class Match:
    def auth_admin(self, key, admin):
        pass

    def start_game(self, arguments, admin):
        pass

    def stop_game(self, admin):
        pass

    def kill_room(self, admin):
        return False, "OK"

    def list_clients(self, admin):
        pass

    def status(self, admin):
        pass

    def on_new_connection(self, trasnport):
        pass

    def on_auth_key(self, client, key):
        pass

    def on_client_state_changed(self, client, old_state, new_state):
        pass

    def on_game_started(self, game):
        pass

    def on_game_stopped(self, game):
        pass

    def on_round_over(self):
        pass
