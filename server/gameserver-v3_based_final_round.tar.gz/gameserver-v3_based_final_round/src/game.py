import logging
import queue
import random
import threading
from datetime import datetime
from struct import unpack

import pygame
import requests

from sprites.bullet import Bullet
from sprites.ghost import Ghost
from iclientmgr import ClientMgrAdapter, ERR_CLIENT_COUNTERPART_PLAYER_DEAD
from sprites.player import Player
from settings import Settings
from sprites.sprite import Apple, Orange, Pineapple, Strawberry, Watermelon, Block, Fruit
from version import GAME_VERSION

EXIT_WHEN_ALL_PLAYERS_DEAD = False
UNIT_SIZE = 40
ALLOW_KEYBOARD_CONTROL = True
MAX_SECONDS_PER_ROUND = 4 * 60  # 6 min

logger = logging.getLogger(__name__)


class NotifyTask(object):
    NT_ID_DEL_PLAYER = 1

    def __init__(self, _id, *args, **kwargs):
        self.id = _id
        for k, v in kwargs.items():
            setattr(self, k, v)


class PlayerInfo(object):
    def __init__(self, *args, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

    def dump(self):
        if self.alive:
            logger.info('team: %s, alive: %s, scores: %s', self.team_name, self.alive, self.scores)
        else:
            logger.info('team: %s, alive: %s, died time: %s, scores: %s', self.team_name, self.alive, self.died_time,
                        self.scores)


class Game:
    def __init__(self, surface, width, height):
        self.location = []
        self.surface = surface
        self.screen_units = width // UNIT_SIZE
        self.bullet_group = pygame.sprite.Group()
        self.player_group = pygame.sprite.Group()
        self.ghost_group = pygame.sprite.Group()
        self.apple_group = pygame.sprite.Group()
        self.watermelon_group = pygame.sprite.Group()
        self.block_group = pygame.sprite.Group()
        self.strawberry_group = pygame.sprite.Group()
        self.pineapple_group = pygame.sprite.Group()
        self.orange_group = pygame.sprite.Group()
        self.fruit_group = pygame.sprite.Group()
        self.lock = threading.RLock()
        self.round_start_time = datetime.now()
        self.dead_player_info = []
        self.game_event_listeners = []
        self.started = False
        self.first_update = True
        # Hold all sprites except ghosts.
        self.sprites = []
        # Hold all blocks and it's position.
        self.blocks = {}
        self.notify_task_queue = queue.Queue()
        self.notify_thread = threading.Thread(target=self.__notify_thread, name='NotifyThread')
        self.notify_thread.start()
        # Keep the load call at last line.
        self.load()
        # 以前端给后端发送的数据为信号来更新游戏帧数的FLAG
        self.__update_frame = False
        self.steps = []
        # 玩家出生位置
        self.borns = [0, 7, 14, 3 * 25 + 4, 3 * 25 + 11, 7 * 25, 7 * 25 + 14, 11 * 25 + 4, 11 * 25 + 11, 14 * 25,
                      14 * 25 + 7, 14 * 25 + 14, 19 * 25 + 4, 19 * 25 + 14, 23 * 25 + 4, 23 * 25 + 22]


    def collect_player_step(self, player):
        self.steps[player.index] = player.step_count

    def collect_player_group_steps(self):
        for player in self.player_group:
            self.steps[player.index] = player.step_count

    def __notify_thread(self):
        logger.info('%s enter', threading.currentThread().name)
        while True:
            task = self.notify_task_queue.get()
            if task is None:
                break
            if task.id == NotifyTask.NT_ID_DEL_PLAYER:
                # task.player.upload_player_score()
                self.collect_player_step(task.player)
                self.location[task.player.index] = -1
                self.__notify_del_player(task.player)
        logger.info('%s exit', threading.currentThread().name)

    def start(self):
        with self.lock:
            self.started = True
            self.round_start_time = datetime.now()
        self.__notify_game_start()

    def stop(self, exit_process):
        logger.info('stop game with exit_process: %s', exit_process)
        with self.lock:
            self.started = False
            self.collect_player_group_steps()
            # self.__clear_all_data_locked()
        if exit_process:
            self.notify_task_queue.put(None)
        self.__notify_game_stop(exit_process)

    def __handle_terminate_game(self):
        logger.debug('__handle_terminate_game')
        """
        :return: True if need continue otherwise False.
        """
        if len(self.player_group) > 0 or not self.started:
            return True
        if EXIT_WHEN_ALL_PLAYERS_DEAD:
            self.__collect_and_print_round_info()
            self.stop(True)
            return False
        else:
            self.__collect_and_print_round_info()
            self.__reset_game()
            return True

    def __reset_game(self):
        """
        Reset all game data and allow client reconnect to start a new round.
        :return:
        """
        logger.debug('reset game')
        self.stop(False)
        self.load()
        # self.start()  # Do not restart game, let user to this.
        self.update()

    def __clear_all_data_locked(self):
        logger.debug('clear all game data')
        for p in self.player_group:
            p.kill()
            self.__remove_sprite_internal_locked(p)
        for g in self.ghost_group:
            g.kill()
        for s in self.sprites:
            if s is None:
                continue
            s.kill()
            self.__remove_sprite_internal_locked(s)
        self.sprites.clear()
        self.blocks.clear()
        self.dead_player_info.clear()

    def is_started(self):
        with self.lock:
            return self.started

    # def on_key_event(self, is_down, key):
    #     if not ALLOW_KEYBOARD_CONTROL:
    #         return
    #     with self.lock:
    #         for p in self.player_group:
    #             p.dispatch_key_event(is_down, key)

    def load(self):
        logger.debug('load game data')
        bg_size = UNIT_SIZE, UNIT_SIZE
        sprite_groups = {
            Block: {
                'group': self.block_group,
                'num': 80,
            },
            Apple: {
                'group': self.apple_group,
                'num': 109,
            },
            Orange: {
                'group': self.orange_group,
                'num': 109,
            },
            Pineapple: {
                'group': self.pineapple_group,
                'num': 109,
            },
            Strawberry: {
                'group': self.strawberry_group,
                'num': 109,
            },
            Watermelon: {
                'group': self.watermelon_group,
                'num': 109,
            },
        }

        sprite_indexes = random.sample(range(0, self.screen_units * self.screen_units),
                                       self.screen_units * self.screen_units)
        self.sprites = [None] * self.screen_units * self.screen_units

        def generate_sprites(clazz, s, e, sprite_group):
            for n in range(s, e):
                sprite = clazz()
                location = random.sample(sprite_indexes, 1)
                if isinstance(sprite, Block):
                    while location[0] < 25 or location[0] > 610 or (location[0] + 1)% self.screen_units == 1 or (location[0] + 1) % self.screen_units == 0:
                        location = random.sample(sprite_indexes, 1)
                sprite_indexes.remove(location[0])
                sprite_index = location[0]
                self.sprites[sprite_index] = sprite
                start_pos = (sprite_index % self.screen_units) * UNIT_SIZE, (
                        sprite_index // self.screen_units) * UNIT_SIZE
                sprite.load(start_pos, bg_size)
                sprite_group.add(sprite)
                if isinstance(sprite, Block):
                    self.blocks[sprite_index] = sprite
                elif isinstance(sprite, Fruit):
                    self.fruit_group.add(sprite)

        # Initialize sprites.
        start = 0
        for clazz, sprite_def in sprite_groups.items():
            end = start + sprite_def['num']
            generate_sprites(clazz, start, end, sprite_def['group'])
            start = end

        self.__generate_ghosts()

    def __collect_and_print_round_info(self):
        live_player_info = []
        for p in self.player_group:
            live_player_info.append(self.__create_player_info(p))
        live_player_info.sort(reverse=True, key=lambda e: e.scores)
        self.dead_player_info.sort(reverse=True, key=lambda e: e.died_time)

        logger.info('*************** Game Round Result ***************')
        for pi in live_player_info:
            pi.dump()
        for pi in self.dead_player_info:
            pi.dump()
        logger.info('*************************************************')

    def update(self):
        """
        :return: True if game process need continue, otherwise False.
        """
        if self.started:
            if self.player_group.__len__() <= 1:
                for player in self.player_group:
                    player.step_count += 1
                self.stop(True)
                return False
        if self.started and MAX_SECONDS_PER_ROUND > 0:
            now = datetime.now()
            t_delta = now - self.round_start_time
            if t_delta.seconds >= MAX_SECONDS_PER_ROUND:
                logger.info('game round timeout')
                self.__collect_and_print_round_info()
                self.__reset_game()
                return False

        if not self.__update_frame:
            return True
        with self.lock:
            if self.started or self.first_update:
                self.first_update = False
                self.__update_players_locked()
                self.__detect_collision_players_blocks_locked()
                self.__update_ghost_locked()
                self.__update_bullet_locked()
                self.__detect_collision_bullets_ghosts_locked()
                self.__detect_collision_bullets_blocks_locked()
                self.__detect_collision_bullets_bullets_locked()
                self.__detect_collision_bullets_players_locked()
                self.__detect_collision_players_players_locked()
                self.__detect_collision_players_ghosts_locked()

                self.__detect_collision_players_fruits_locked()

                # for player in self.player_group:
                #     self.__update_map_data(player)
                for player in self.player_group:
                    self.scores[player.index] = player.score
                    self.location[
                        player.index] = player.rect.top // UNIT_SIZE * self.screen_units + player.rect.left // UNIT_SIZE
                    print("liu")
                    print(self.location)

        return True

    def __update_players_locked(self):
        for player in self.player_group:
            player.step_count += 1
            if((player.step_count%2)==0):
                player.score -= 1
            if(player.score < 0):
                self.__delete_player(player=player)
                continue
            player.move_and_sync_direction(self.screen_units, UNIT_SIZE)
            if player.is_firing() and player.fire_bullet():
                bullet = Bullet()
                bullet.load(player, (UNIT_SIZE, UNIT_SIZE))
                self.bullet_group.add(bullet)
        self.player_group.update()

    def __update_ghost_locked(self):
        for ghost in self.ghost_group:
            ghost.move(self.ghost_group, self.player_group, self.screen_units, UNIT_SIZE)
        self.ghost_group.update()

    def __update_bullet_locked(self):
        for bullet in self.bullet_group:
            # if not bullet.alive():
            #     continue
            bullet.move_and_sync_direction(self.screen_units, UNIT_SIZE)
        self.bullet_group.update()

    def __detect_collision_bullets_bullets_locked(self):
        do_kill_bullets = {}
        for bullet in self.bullet_group:
            if bullet in do_kill_bullets:
                continue
            tmp_bullet_group = self.bullet_group.copy()
            tmp_bullet_group.remove(bullet)
            for b in tmp_bullet_group:
                if bullet.shadow == b.rect and bullet.rect == b.shadow:
                    if bullet.owner != b.owner:
                        do_kill_bullets[bullet] = True
                        do_kill_bullets[b] = True
        for b, _ in do_kill_bullets.items():
            b.kill()

        do_kill_bullets = {}
        for bullet in self.bullet_group:
            if bullet in do_kill_bullets:
                continue
            tmp_bullet_group = self.bullet_group.copy()
            tmp_bullet_group.remove(bullet)
            collided_bullets = pygame.sprite.spritecollide(bullet, tmp_bullet_group, False,
                                                           pygame.sprite.collide_rect_ratio(0.5))
            if len(collided_bullets) > 1:
                logger.warning('FIXME: one bullet hurt more than one bullet')
            if len(collided_bullets) > 0:
                for b in collided_bullets:
                    if bullet.owner != b.owner:
                        do_kill_bullets[bullet] = True
                        do_kill_bullets[b] = True
        for b, _ in do_kill_bullets.items():
            b.kill()

    def __detect_collision_bullets_blocks_locked(self):
        pygame.sprite.groupcollide(self.bullet_group, self.block_group, True, False,
                                   pygame.sprite.collide_rect_ratio(0.5))
        for bullet in self.bullet_group:
            for block in self.block_group:
                if bullet.shadow == block.rect:
                    bullet.kill()

    def __detect_collision_bullets_ghosts_locked(self):
        do_kill_bullets = {}
        do_kill_ghosts = {}
        attacker = pygame.sprite.groupcollide(self.bullet_group, self.ghost_group, False, False,
                                              pygame.sprite.collide_rect_ratio(0.5))
        for bullet, ghosts in attacker.items():
            firer = bullet.owner
            firer.score += Settings['hit_ghost_score']
            if bullet not in do_kill_bullets:
                do_kill_bullets[bullet] = True
            if ghosts[0] not in do_kill_ghosts:
                do_kill_ghosts[ghosts[0]] = True
            # TODO: generate ghost in the next update loop.

        for ghost in self.ghost_group:
            for bullet in self.bullet_group:
                if ghost.shadow == bullet.rect and ghost.rect == bullet.shadow:
                    firer = bullet.owner
                    firer.score += Settings['hit_ghost_score']
                    if bullet not in do_kill_bullets:
                        do_kill_bullets[bullet] = True
                    if ghost not in do_kill_ghosts:
                        do_kill_ghosts[ghost] = True
        for b, _ in do_kill_bullets.items():
            b.kill()
        for g, _ in do_kill_ghosts.items():
            g.kill()
            self.__generate_ghosts()

    def __detect_collision_bullets_players_locked(self):
        """
        :return: True if any player died.
        """
        do_kill_bullets = {}
        do_kill_players = {}
        attacker = pygame.sprite.groupcollide(self.bullet_group, self.player_group, True, False,
                                              pygame.sprite.collide_rect_ratio(0.5))
        has_player_died = False
        for bullet, players in attacker.items():
            if len(players) > 1:
                logger.warning('FIXME: one bullet hurt more than one player')
            for player in players:
                injured_player = player
                firer = bullet.owner
                if firer == injured_player:
                    continue
                else:
                    injured_player.health -= 1
                    firer.score += Settings['hit_tank_score']
                if injured_player.health == 0:
                    has_player_died = True
                if player not in do_kill_players:
                    do_kill_players[player] = True
                if bullet not in do_kill_bullets:
                    do_kill_bullets[bullet] = True

                # self.__delete_player(injured_player)
        for player in self.player_group:
            for bullet in self.bullet_group:
                if player.shadow == bullet.rect and player.rect == bullet.shadow:
                    injured_player = player
                    firer = bullet.owner
                    if firer == injured_player:
                        continue
                    else:
                        injured_player.health -= 1
                        firer.score += Settings['hit_tank_score']
                    if injured_player.health == 0:
                        has_player_died = True
                    if player not in do_kill_players:
                        do_kill_players[player] = True
                    if bullet not in do_kill_bullets:
                        do_kill_bullets[bullet] = True
        for b, _ in do_kill_bullets.items():
            b.kill()
        for p, _ in do_kill_players.items():
            self.__delete_player(p)
        return has_player_died

    def __detect_collision_players_blocks_locked(self):
        conflicts = pygame.sprite.groupcollide(self.player_group, self.block_group, False, False,
                                               pygame.sprite.collide_rect_ratio(0.5))
        for players, blocks in conflicts.items():
            players.X -= players.velocity.X
            players.Y -= players.velocity.Y
            players.update()

    def __detect_collision_players_players_locked(self):
        for player in self.player_group:
            tmp_player_group = self.player_group.copy()
            tmp_player_group.remove(player)
            collided_players = pygame.sprite.spritecollide(player, tmp_player_group, False,
                                                           pygame.sprite.collide_rect_ratio(0.5))
            if len(collided_players) > 1:
                logger.warning('FIXME: one player hurt more than one player')
            if len(collided_players) > 0:
                for p in collided_players:
                    self.__delete_player(p)
            for p in tmp_player_group:
                if player.shadow == p.rect and player.rect == p.shadow:
                    self.__delete_player(p)

    def __detect_collision_players_fruits_locked(self):
        score_players = pygame.sprite.groupcollide(self.player_group, self.fruit_group, False, True,
                                                   pygame.sprite.collide_rect_ratio(0.5))
        for p, fruits in score_players.items():
            p.eat_fruits(fruits)
            for f in fruits:
                self.__remove_sprite_internal_locked(f)

    def __detect_collision_players_ghosts_locked(self):
        """
        :return: True if any player died.
        """
        players = pygame.sprite.groupcollide(self.player_group, self.ghost_group, False, False,
                                             pygame.sprite.collide_rect_ratio(0.5))
        has_player_died = False
        for p in players:
            p.health -= 1
            if p.health == 0:
                self.__delete_player(p)
                has_player_died = True

        for player in self.player_group:
            for ghost in self.ghost_group:
                if player.shadow == ghost.rect and player.rect == ghost.shadow:
                    self.__delete_player(player)
                    has_player_died = True
        return has_player_died

    def __add_dead_player_info(self, player):
        self.dead_player_info.append(self.__create_player_info(player))

    def __delete_player(self, player):
        player.kill()
        self.__remove_sprite_internal_locked(player)
        self.__add_dead_player_info(player)
        self.notify_task_queue.put(NotifyTask(NotifyTask.NT_ID_DEL_PLAYER, player=player))
        generate_ghost=(0,1,2)
        if(random.choice(generate_ghost)==0):
            self.__generate_ghosts()
        #self.__generate_ghosts()

    # TODO: move this method to Player class.
    def __create_player_info(self, player):
        return PlayerInfo(died_time=datetime.now(), scores=player.score, team_name=player.team_name,
                          alive=player.alive())

    def __generate_ghosts_borns(self):
        # 幽灵出生位置
        ghost_borns = [(5, 4), (5, 12), (10, 5), (10, 12), (2, 7), (2, 13), (13, 7), (13, 14), (4, 8), (4, 12),
                       (8, 7), (8, 13)]
        ghost_born = random.choice(ghost_borns)
        for i in self.location:
            if (ghost_born[0]*25+ghost_born[1]) == i:
                self.__generate_ghosts_borns()
        return ghost_born[0],ghost_born[1]

    def __generate_ghosts(self):
        # if self.ghost_group.__len__() > 0:
        #     return
        bg_size = UNIT_SIZE, UNIT_SIZE
        x,y=self.__generate_ghosts_borns()
        ghost_fix_pos = ((x,y, True),)
        # ghost_fix_pos = ()
        for g_p in ghost_fix_pos:
            ghost = Ghost()
            ghost.X, ghost.Y = g_p[0] * UNIT_SIZE, g_p[1] * UNIT_SIZE
            ghost.moving = g_p[2]
            ghost.load((ghost.X, ghost.Y), bg_size, 1)
            self.ghost_group.add(ghost)

    def __remove_sprite_internal_locked(self, sprite):
        index = self.sprites.index(sprite)
        self.sprites[index] = None
        #logger.debug('%s removed at index: %s', sprite, self.get_sprite_index(sprite))

    def draw(self):
        """
        Draw all objects to self.surface.
        :return:
        """

        # Fill background.
        self.surface.fill((50, 50, 100))

        # Draw all sprites.
        with self.lock:
            for s in self.sprites:
                if s is None:
                    continue
                self.surface.blit(s.image, s.rect)
                if isinstance(s, Player):
                    s.draw_additional_info(self.surface)
            self.ghost_group.draw(self.surface)
            self.bullet_group.draw(self.surface)
        self.__notify_frame()

    # def client_error(self, client, err):
    #     logger.debug('client error: %s', err)
    #     # Avoid recursive call.
    #     if err == ERR_CLIENT_COUNTERPART_PLAYER_DEAD:
    #         return
    #     player = client.get_counterpart_player()
    #     if player is None:
    #         return
    #     with self.lock:
    #         player.kill()
    #         self.__remove_sprite_internal_locked(player)
    #         self.__add_dead_player_info(player)
    #     self.__notify_del_player(player)
    #     with self.lock:
    #         self.__handle_terminate_game()

    def get_sprite_index(self, sprite):
        return sprite.rect.top // UNIT_SIZE * self.screen_units + sprite.rect.left // UNIT_SIZE

    def dump(self):
        # TODO: for debug purpose, dump all data to check resource leak.
        pass

    def __get_new_player_position_locked(self):
        empty_indexes = random.sample(self.borns, 1)
        self.borns.remove(empty_indexes[0])
        empty_index = empty_indexes[0]
        self.fruit_group.remove(self.sprites[empty_index])
        self.block_group.remove(self.sprites[empty_index])
        self.__remove_sprite_internal_locked(self.sprites[empty_index])
        x = empty_index % self.screen_units * UNIT_SIZE
        y = empty_index // self.screen_units * UNIT_SIZE
        logger.info('new player index: %s, x: %s, y: %s', empty_index, x, y)
        return empty_index, x, y

    def register_game_event_listener(self, listener):
        with self.lock:
            if listener in self.game_event_listeners:
                logger.warning('game event listener already exist: %s', listener)
                return
            self.game_event_listeners.append(listener)

    def __notify_game_start(self):
        logger.info('notify game start now...')
        for listener in self.__clone_game_event_listeners():
            listener.on_game_start(self)

    def __notify_game_stop(self, exit_process):
        logger.info('notify game stop now...')
        for listener in self.__clone_game_event_listeners():
            listener.on_game_stop(self, exit_process)

    def __notify_del_player(self, player):
        logger.info('notify delete player: %s', player)
        for listener in self.__clone_game_event_listeners():
            listener.on_del_player(self, player)

    def __notify_frame(self):
        if not self.__update_frame:
            return
        for listener in self.__clone_game_event_listeners():
            listener.on_frame(self)
        self.__update_frame = False

    def __clone_game_event_listeners(self):
        with self.lock:
            listeners = list(self.game_event_listeners)
        return listeners

    def overwrite_map_data(self, who, map_data, sprite_group):
        for s in sprite_group:
            s_index = s.rect.top // UNIT_SIZE * self.screen_units + s.rect.left // UNIT_SIZE
            map_data[s_index] = s.get_map_char(who)

    def setup_players(self, num):
        print("1")
        self.scores = [0] * num
        self.steps = [0] * num
        for i in range(num):
            index, x, y = self.__get_new_player_position_locked()
            logger.info("liu index:{} x:{} y:{}".format(index,x,y))
            player = Player(index=i)
            player.load((x, y), (UNIT_SIZE, UNIT_SIZE))
            player.update()
            self.player_group.add(player)
            self.sprites[index] = player
            self.location.append(index)
            # TODO: create players.
        for listener in self.__clone_game_event_listeners():
            listener.on_frame(self)
        # self.__update_frame = True

    def update_control_data(self, data):
        # TODO: parse data and update players according the control data protocol.
        control = data[2]
        for player in self.player_group:
            # 如果收到的数据为'X'则代表这个玩家挂了
            if control[player.index * 2] == 'X':
                self.__delete_player(player)
            else:
                player.update_direction(control[player.index * 2])
                player.update_fire(control[player.index * 2 + 1])
        # 游戏可以更新frame了
        self.__update_frame = True
