import asyncio
import logging
import struct
import sys
from struct import pack, unpack

from dataserver.databroker import StdInDataBroker
from dataserver.idataconsumer import IDataConsumer
from dataserver.protocolv1 import ProtocolV1, DATA_TYPE_PLAYER_NUM, DATA_TYPE_CONTROL_DATA, DATA_TYPE_GAME_OVER, \
    DATA_TYPE_NOTIFY_MAP
from game import UNIT_SIZE
from igameeventlistener import GameEventAdapter
from igamemgr import IGameManager
from ui import UI

logger = logging.getLogger(__name__)


class GameMgr(IGameManager, GameEventAdapter, IDataConsumer):
    def __init__(self):
        self.data_broker = None
        self.game = UI.game
        self.register_game_events()
        self.setup_data_server()
        self.map_data = ''

    def setup_data_server(self):
        self.data_broker = StdInDataBroker(self)
        self.data_broker.set_protocol(ProtocolV1(self.data_broker))

    def on_data(self, data):
        logger.debug('on data: %s', data)
        _type, _size, _data = data
        if _type == DATA_TYPE_PLAYER_NUM:
            player_num = _data
            self.game.setup_players(player_num)
            self.game.start()
        elif _type == DATA_TYPE_CONTROL_DATA:
            self.game.update_control_data(data)

    async def main(self):
        await self.data_broker.monitor_data_input()

    def run(self):
        asyncio.run(self.main())
        logger.info('GameMgr end run...')

    def register_game_events(self):
        self.game.register_game_event_listener(self)

    def on_game_start(self, game):
        logger.debug('game started')

    def on_game_stop(self, game, exit_process=False):
        logger.debug('game stopped')
        if hasattr(game, 'scores'):
            send = 'GAMEOVER ' + ' '.join(str(i) for i in game.scores) + ' ' + ' '.join(str(i) for i in game.steps)+'\n'
            sys.stdout.buffer.write(send.encode())
            sys.stdout.flush()
        self.data_broker.stop()

    def on_frame(self, game):
        size = game.screen_units * game.screen_units
        data = ['0'] * size
        for i, s in enumerate(game.sprites):
            if s is None:
                continue
            s_index = s.rect.top // UNIT_SIZE * game.screen_units + s.rect.left // UNIT_SIZE
            data[s_index] = s.get_map_char(None)

        # Overwrite data by player
        game.overwrite_map_data(None, data, game.player_group)
        # Overwrite data by ghosts.
        game.overwrite_map_data(None, data, game.ghost_group)
        # Overwrite data by bullets.
        game.overwrite_map_data(None, data, game.bullet_group)


        # send self.map_data to front
        send = 'MAP ' + ''.join(data) + '\n'
        sys.stdout.buffer.write(send.encode())

        send = 'LOCATION ' + ' '.join(str(i) for i in game.location) + '\n'
        sys.stdout.buffer.write(send.encode())

        send = 'SCORE ' + ' '.join(str(i) for i in game.scores) + '\n'

        sys.stdout.buffer.write(send.encode())
        sys.stdout.flush()
	# TODO: pack and send map data according to map data protocol.


GMR = GameMgr()
