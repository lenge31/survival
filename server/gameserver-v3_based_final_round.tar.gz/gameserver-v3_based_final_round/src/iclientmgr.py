from abc import ABC, abstractmethod

ERR_OK = 0x00
ERR_DATA_FORMAT = 0x1
ERR_KEY = 0x02
ERR_CLIENT_DISCONNECT = 0x03
ERR_CLIENT_SEND_DATA = 0x04
ERR_CLIENT_MAX_SIZE = 0x05
ERR_CLIENT_COUNTERPART_PLAYER_DEAD = 0x06
ERR_UNKNOWN = 0x99

MSG_TYPE_LEN = 2
DATA_LEN = 4
ERR_CODE_LEN = 2

KEY_LEN = 0x20
MAP_DATA_LEN = 0x8

MSG_TYPE_HANDSHAKE = 0x00
MSG_TYPE_TURN = 0x01
MSG_TYPE_FORWARD = 0x02
MSG_TYPE_GET_POSI_DIRE = 0x03
MSG_TYPE_GET_MAP_DATA = 0x04
MSG_TYPE_FIRE = 0x05
MSG_TYPE_MAP_DATA_UPDATE = 0x06


def get_resp_msg_type(msg_type):
    return 0x10 | msg_type


class IClientMgr(ABC):
    @abstractmethod
    def add_client(self, client):
        """
        Add client to client manager and make it ready for communicating
        between server and client.
        :param Client client: client to be added
        :return: True if client add successfully, otherwise return False
        """
        return False

    @abstractmethod
    def client_error(self, client, err):
        """
        Called when client happened some error with error code specified by err.
        :param client: client which happened error
        :param err: error code
        """
        pass

    def is_key_exist(self, key):
        """
        :param str key:
        :return: return True if client handshake key exist, otherwise return False
        """
        return False

    def new_valid_client(self, client):
        return False


class ClientMgrAdapter(IClientMgr):
    def add_client(self, client):
        return False

    def client_error(self, client, err):
        pass

    def is_key_exist(self, key):
        return False

    def new_valid_client(self, client):
        return False
