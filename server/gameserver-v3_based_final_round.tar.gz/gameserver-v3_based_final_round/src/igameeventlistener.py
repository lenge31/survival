from abc import ABC, abstractmethod


class IGameEventListener(ABC):
    @abstractmethod
    def on_game_start(self, game):
        pass

    @abstractmethod
    def on_game_paused(self, game):
        pass

    @abstractmethod
    def on_game_stop(self, game, exit_process=False):
        pass

    @abstractmethod
    def on_new_player(self, game, player, client):
        pass

    @abstractmethod
    def on_del_player(self, game, player):
        pass

    @abstractmethod
    def on_frame(self, game):
        pass


class GameEventAdapter(IGameEventListener):
    def on_game_start(self, game):
        pass

    def on_game_paused(self, game):
        pass

    def on_game_stop(self, game, exit_process=False):
        pass

    def on_new_player(self, game, player, client):
        pass

    def on_del_player(self, game, player):
        pass

    def on_frame(self, game):
        pass
