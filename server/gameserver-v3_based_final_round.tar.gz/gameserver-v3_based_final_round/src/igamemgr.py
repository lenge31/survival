import threading
from abc import ABC, abstractmethod


class IGameManager(ABC):
    @abstractmethod
    def run(self):
        raise NotImplementedError()

    def register_game_events(self):
        pass

    def run_in_new_thread(self):
        threading.Thread(target=self.run, name='GMR-SvrThr').start()

    def quit(self):
        pass
