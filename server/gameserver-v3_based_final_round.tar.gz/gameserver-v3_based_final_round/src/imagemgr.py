import pygame


class ImageMgrImpl(object):
    def __init__(self):
        self.cache = {}

    def get_image(self, path):
        if path not in self.cache:
            image = pygame.image.load(path)
            self.cache[path] = image
        return self.cache[path]


ImageMgr = ImageMgrImpl()
