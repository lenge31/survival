import os
import logging

# Root directory of this project which contains the folder 'src'.
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_BASE_DIR = os.path.join(BASE_DIR, 'logs')

if not os.path.isdir(LOG_BASE_DIR):
    os.makedirs(LOG_BASE_DIR)

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose_fmt': {
            'format': '%(asctime)s %(levelname)-5s %(process)-6d %(thread)-6d %(module)s %(message)s'
        },
        'simple_fmt': {
            'format': '%(asctime)s %(levelname)-5s %(message)s'
        },
    },
    'handlers': {
        'f_general': {
            'level': 'DEBUG',
            'class': 'logging.FileHandler',
            'filename': '%s/logs/log.log' % BASE_DIR,
            'formatter': 'verbose_fmt',
        },
        'c_general': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'verbose_fmt',
        },
        # 'f_demo': {
        #     'level': 'DEBUG',
        #     'class': 'logging.FileHandler',
        #     'filename': '%s/logs/demo.log' % BASE_DIR,
        #     'formatter': 'simple',
        # },
    },
    'root': {
        'handlers': ['f_general'],
        'level': 'DEBUG',
        'propagate': True,
    },
    'loggers': {
        # You can config specific module log strategy with the logger name as
        # the key.
        # 'main': {
        #     'handlers': ['f_general'],
        #     'level': 'DEBUG',
        #     'propagate': True,
        # },
    },
}

logger = logging.getLogger(__name__)
