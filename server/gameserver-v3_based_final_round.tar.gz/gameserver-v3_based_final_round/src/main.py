import logging.config

from log import LOGGING, logger
from version import GAME_VERSION

def run():
    # Call gm.run_in_new_thread() if you want the game core logic run in another
    # thread and leave the main thread doing other things like drawing.
    GMR.run_in_new_thread()
    UI.loop()


if __name__ == '__main__':
    # Configure logging with the default configurations.
    logging.config.dictConfig(LOGGING)
    logger.info('Game Server (%s)', GAME_VERSION)

    # Load settings.
    from settings import Settings
    from gamemgrx import GMR
    from ui import UI

    # Re-configure logging.
    logging.config.dictConfig(Settings.logging_config)

    try:
        run()
    except KeyboardInterrupt:
        GMR.quit()
    logger.info('Game Server exit')
