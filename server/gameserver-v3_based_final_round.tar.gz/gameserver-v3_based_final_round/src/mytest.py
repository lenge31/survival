import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("127.0.0.1", 9527))

data = "test socket"

client.send(str.encode(data))
b=client.recv(256)
print(client.getsockname())
print(b.decode('utf-8'))