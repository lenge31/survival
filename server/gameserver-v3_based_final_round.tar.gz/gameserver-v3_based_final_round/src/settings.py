import logging
import os

import demjson
from deepmerge import always_merger
from log import LOGGING
from utils.singleton import Singleton

logger = logging.getLogger(__name__)


class SettingMgr(metaclass=Singleton):
    def __init__(self, *args, **kwargs):
        self.settings = {}

        # Keep this the last line of __init__.
        self.__init_default_settings()

        if self.settings.get('hide_pygame_prompt', True):
            os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = 'hide'

    def __init_default_settings(self):
        self.settings['logging'] = {**LOGGING}
        self.settings['server'] = {'ip': '127.0.0.1', 'port': 9527}
        self.load(config_file='gm_default_config.json')
        self.load(config_file='gm_config.json')

    def __getitem__(self, item):
        return self.settings[item]

    def __setitem__(self, key, value):
        self.settings[key] = value

    def get(self, key, default):
        return self.settings.get(key, default)

    def load(self, config_file, *args, **kwargs):
        if os.path.isfile(config_file):
            settings = demjson.decode_file(config_file)
            always_merger.merge(self.settings, settings)
        logger.debug('after load config file %s, settings is: %s', config_file,
                     self.settings)

    @property
    def logging_config(self):
        return self.settings['logging']


Settings = SettingMgr()
