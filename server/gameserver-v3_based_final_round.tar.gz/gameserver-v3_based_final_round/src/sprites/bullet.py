import threading

from pygame.rect import Rect

from imagemgr import ImageMgr
from sprites.sprite import MovableSprite, BULLET_DIRECTION_MAP_NUM_TO_CHAR


class Bullet(MovableSprite):
    res = "res1//bullet.png"

    def __init__(self):
        super(Bullet, self).__init__()
        self.lock = threading.RLock()
        self.shadow = Rect(0, 0, 40, 40)

    def load(self, firer, bg_size):
        self.image = ImageMgr.get_image(self.res)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = firer.X, firer.Y
        self.X, self.Y = firer.X, firer.Y
        self.width, self.height = bg_size[0], bg_size[1]
        self.owner = firer
        self.direction = firer.direction
        self.shadow.left, self.shadow.top = self.rect.left, self.rect.top

    def update(self):
        self.shadow.left, self.shadow.top = self.rect.left, self.rect.top
        self.rect.left, self.rect.top = self.X, self.Y

    def move_locked(self, screen_columns, column_width):
        max_w, max_h = (screen_columns - 1) * column_width, (screen_columns - 1) * column_width
        self.velocity = self.calc_velocity(column_width)
        self.X += self.velocity.X
        self.Y += self.velocity.Y
        self.limit_position(max_w, max_h, True)

    def move_and_sync_direction(self, screen_columns, column_width):
        with self.lock:
            self.move_locked(screen_columns, column_width)

    def get_direction_char(self):
        with self.lock:
            return BULLET_DIRECTION_MAP_NUM_TO_CHAR[self.direction]
