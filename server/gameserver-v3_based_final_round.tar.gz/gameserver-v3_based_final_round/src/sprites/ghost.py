import logging
import math
import sys

import pygame
from pygame.rect import Rect

from imagemgr import ImageMgr
from sprites.sprite import DIRECTION_W, DIRECTION_D, DIRECTION_S, DIRECTION_A
from sprites.sprite import MovableSprite

logger = logging.getLogger(__name__)


class Ghost(MovableSprite):
    res = 'res1//ghost.png'

    def __init__(self):
        super(Ghost, self).__init__()
        self.moving = True
        self.frame = 0
        self.frame_width = 1
        self.frame_height = 1
        self.shadow = Rect(0, 0, 40, 40)

    def load(self, start_pos, bg_size, img_columns):
        self.image = ImageMgr.get_image(self.res)
        self.frame_width = bg_size[0]
        self.frame_height = bg_size[1]
        self.X, self.Y = start_pos
        self.rect = pygame.rect.Rect(self.X, self.Y, self.frame_width, self.frame_height)
        self.shadow.left, self.shadow.top = self.rect.left, self.rect.top

    def update(self, current_time=0, rate=60):
        # logger.info('ghost.update called')
        self.shadow.left, self.shadow.top = self.rect.left, self.rect.top
        self.rect.left, self.rect.top = self.X, self.Y

    def on_get_frame_position(self):
        frame_x = self.frame * self.frame_width
        frame_y = self.frame * self.frame_height
        return frame_x, frame_y

    def get_nearest_player(self, players):
        nearest_one = None
        shortest_dist = sys.maxsize
        for player in players:
            dist = math.sqrt(math.pow(self.X - player.X, 2) + math.pow(self.Y - player.Y, 2))
            if shortest_dist > dist:
                shortest_dist = dist
                nearest_one = player
        return nearest_one

    def get_direction_char(self):
        return 'G'

    def move(self, own_kinds, targets, screen_columns, column_width):
        if self.moving:
            max_w, max_h = (screen_columns - 1) * column_width, (screen_columns - 1) * column_width
            # Pursue the nearest target.
            target = self.get_nearest_player(targets)
            if target is None:
                return
            dir_x, dir_y = target.X - self.X, target.Y - self.Y
            if abs(dir_x) > abs(dir_y):
                if dir_x > 0:
                    self.direction = DIRECTION_D
                else:
                    self.direction = DIRECTION_A
            else:
                if dir_y > 0:
                    self.direction = DIRECTION_S
                else:
                    self.direction = DIRECTION_W
            self.velocity = self.calc_velocity(column_width)
            self.X += self.velocity.X
            self.Y += self.velocity.Y

            # Make sure ghosts do not overlap.
            retreat = False
            for other_g in own_kinds:
                if other_g == self:
                    continue
                if other_g.X == self.X and other_g.Y == self.Y:
                    retreat = True
            if retreat:
                self.X -= self.velocity.X
                self.Y -= self.velocity.Y

            # Make sure ghost is in legal area.
            self.limit_position(max_w, max_h)

        # Toggle the moving status.
        # self.moving = not self.moving
