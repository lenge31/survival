from datetime import datetime
import logging
import threading

import pygame
import requests

from imagemgr import ImageMgr
from pygame.rect import Rect

from settings import Settings
from sprites.sprite import DIRECTION_W, DIRECTION_D, DIRECTION_S, DIRECTION_A, DIRECTION_MAP_NUM_TO_CHAR
from sprites.sprite import MovableSprite
from version import GAME_VERSION

logger = logging.getLogger(__name__)


class Player(MovableSprite):
    res = 'res1//player.png'

    def __init__(self, index=-1):
        super(Player, self).__init__()
        self.lock = threading.RLock()
        self.moving = False
        self.health = 1
        self.score = 10
        self.step_count = 0
        self.first_frame = 0
        self.frame = 0
        self.old_frame = -1
        self.frame_width = 1
        self.frame_height = 1
        self.team_name = ''
        self.fire = False
        self.client = None
        self.ready = False
        # self.last_tick = datetime.now()
        self.shadow = Rect(0, 0, 40, 40)
        self.map_data = ''
        # the index of 11 players
        self.index = index
        self.create_time = datetime.now()
        pygame.font.init()
        self.font = pygame.font.SysFont('arial', 20)
        self.font.set_bold(True)

    def load(self, start_pos, bg_size):
        self.frame_width = bg_size[0]
        self.frame_height = bg_size[1]

        self.X, self.Y = start_pos
        self.rect = pygame.rect.Rect(self.X, self.Y, self.frame_width, self.frame_height)
        self.shadow.left, self.shadow.top = self.rect.left, self.rect.top

    def get_map_char(self, who):
        c = super(Player, self).get_map_char(who)
        # if self == who:
        #     c = c.upper()
        return c

    def get_direction_char(self):
        with self.lock:
            return DIRECTION_MAP_NUM_TO_CHAR[self.direction]

    def attach_client(self, client):
        with self.lock:
            self.client = client

    def get_attached_client(self):
        with self.lock:
            return self.client

    def update(self, current_time=0, rate=60):
        # logger.info('player.update called')
        if self.direction == DIRECTION_W:
            file_name = 'res1//w.png'
        elif self.direction == DIRECTION_D:
            file_name = 'res1//d.png'
        elif self.direction == DIRECTION_S:
            file_name = 'res1//s.png'
        elif self.direction == DIRECTION_A:
            file_name = 'res1//a.png'

        self.image = ImageMgr.get_image(file_name)
        self.shadow.left, self.shadow.top = self.rect.left, self.rect.top
        self.rect.left, self.rect.top = self.X, self.Y

    def process_control_data(self, data):
        self.update_tick(data)
        self.update_fire(data)
        self.update_direction(data)

    def update_status(self, data):
        if data != b'k' and data != b'K':
            return
        with self.lock:
            logger.info('>>>: ' + self.team_name + ' READY!')
            self.ready = True

    def update_fire(self, data):
        if data != 'v':
            return
        with self.lock:
            self.fire = True

    def update_tick(self, data):
        pass
        # if data != b'h' and data != b'H':
        #     return
        # with self.lock:
        #     self.last_tick = datetime.now()

    def update_team_name(self, team_name):
        with self.lock:
            self.team_name = team_name

    def update_direction(self, new_direction):
        logger.info('new direction %s, current direct: %s, pre_direct: %s', new_direction, self.direction,
                    self.pre_direction)
        direction_map = {
            'w': DIRECTION_W,
            'd': DIRECTION_D,
            's': DIRECTION_S,
            'a': DIRECTION_A,
        }
        with self.lock:
            if new_direction in direction_map:
                self.direction = direction_map[new_direction]
                self.moving = self.pre_direction == self.direction
                logger.info('next moving: %s', self.moving)

    def is_firing(self):
        with self.lock:
            return self.fire

    def reset_fire_status_locked(self):
        self.fire = False

    def fire_bullet(self):
        """
        :return: True if fire bullet ok, otherwise False.
        """
        real_fire = False
        with self.lock:
            if self.score >= Settings['bullet_cost']:
                self.score -= Settings['bullet_cost']
                real_fire = True
            self.reset_fire_status_locked()
        return real_fire

    def move_locked(self, screen_columns, column_width):
        max_w, max_h = (screen_columns - 1) * column_width, (screen_columns - 1) * column_width
        if not self.moving or self.pre_direction != self.direction:
            return
        self.moving = False
        self.velocity = self.calc_velocity(column_width)
        pre_x, pre_y = self.X, self.Y
        self.X += self.velocity.X
        self.Y += self.velocity.Y
        self.limit_position(max_w, max_h)

        # self.step_count += 1
        logger.info('new X, Y: (%s, %s), pre X, Y: (%s, %s), index: %s', self.X, self.Y, pre_x, pre_y,
                    Player.get_index_in_map(self.X, self.Y, screen_columns, column_width))

    def eat_fruits(self, fruits):
        with self.lock:
            for f in fruits:
                pre_score = self.score
                self.score += f.score
                logger.info('%s eats fruit: %s, pre_score:cur_score=(%s, %s)', self, f, pre_score, self.score)

    def draw_additional_info(self, surface):
        color = 255, 255, 255
        team_name = self.font.render('{:>6}'.format(self.index), True, color)
        team_score = self.font.render('{:>6}'.format(self.score), True, color)
        step = self.font.render('{:>6}'.format(self.step_count), True, color)
        surface.blit(team_name, (self.X, self.Y))
        surface.blit(team_score, (self.X, self.Y + 20))
        surface.blit(step, (self.X, self.Y - 20))
        # pygame.draw.rect(surface, (255, 0, 0),
        #                  Rect(self.X, self.Y - 10, self.health * 40 // 3, 10))

    @staticmethod
    def get_index_in_map(x, y, screen_columns, column_width):
        return y // column_width * screen_columns + x // column_width

    def sync_direction_locked(self):
        # Turn direction will add 1 step record.
        if self.pre_direction != self.direction:
            # self.step_count += 1
            self.pre_direction = self.direction

    def move_and_sync_direction(self, screen_columns, column_width):
        with self.lock:
            self.move_locked(screen_columns, column_width)
            self.sync_direction_locked()

    def on_get_frame_position(self):
        frame_x = self.frame * self.frame_width
        frame_y = self.direction * self.frame_height
        return frame_x, frame_y

    def destroy(self):
        logger.info('destroy player: %s', self)
        with self.lock:
            self.client = None

    def dispatch_key_event(self, is_down, key):
        if is_down:
            return
        fire_ctrl = False
        with self.lock:
            # self.last_tick = datetime.now()
            if key in [pygame.K_k]:
                return
            if key in [pygame.K_UP, pygame.K_w]:
                self.direction = DIRECTION_W
            elif key in [pygame.K_RIGHT, pygame.K_d]:
                self.direction = DIRECTION_D
            elif key in [pygame.K_DOWN, pygame.K_s]:
                self.direction = DIRECTION_S
            elif key in [pygame.K_LEFT, pygame.K_a]:
                self.direction = DIRECTION_A
            elif key in [pygame.K_SPACE]:
                self.fire = True
                fire_ctrl = True
            if not fire_ctrl and self.pre_direction == self.direction:
                self.moving = True
