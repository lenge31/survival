import random

import pygame
from imagemgr import ImageMgr

DIRECTION_W = 0
DIRECTION_D = 2
DIRECTION_S = 4
DIRECTION_A = 6

BULLET_DIRECTION_MAP_NUM_TO_CHAR = {
    DIRECTION_W: '^',
    DIRECTION_D: '>',
    DIRECTION_S: 'v',
    DIRECTION_A: '<'
}

DIRECTION_MAP_NUM_TO_CHAR = {
    DIRECTION_W: 'w',
    DIRECTION_D: 'd',
    DIRECTION_S: 's',
    DIRECTION_A: 'a'
}

DIRECTION_MAP_CHAR_TO_NUM = {
    'w': DIRECTION_W,
    'd': DIRECTION_D,
    's': DIRECTION_S,
    'a': DIRECTION_A
}


def get_randomize_direction():
    return random.sample(list(DIRECTION_MAP_NUM_TO_CHAR.keys()), 1)[0]


class Point(object):
    def __init__(self, x, y):
        self.X = x
        self.Y = y


class MySprite(pygame.sprite.Sprite):
    res = None

    def __init__(self):
        super(MySprite, self).__init__()
        self.master_image = None
        self.last_time = 0
        self.X = 0
        self.Y = 0
        self.velocity = Point(0.0, 0.0)

    def load(self, position, bg_size):
        self.image = ImageMgr.get_image(self.res)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = position
        self.width, self.height = bg_size[0], bg_size[1]

    def get_map_char(self, who):
        raise NotImplementedError()


class MovableSprite(MySprite):

    def __init__(self):
        super(MovableSprite, self).__init__()
        self.pre_direction = self.direction = get_randomize_direction()

    def limit_position(self, max_w, max_h, do_kill=False):
        out_of_bound = self.X < 0 or self.X > max_w or self.Y < 0 or self.Y > max_h
        if do_kill and out_of_bound:
            self.kill()
            return

        if not out_of_bound:
            return

        if self.X < 0:
            self.X = 0
        elif self.X > max_w:
            self.X = max_w
        if self.Y < 0:
            self.Y = 0
        elif self.Y > max_h:
            self.Y = max_h

    def calc_velocity(self, vel=1.0):
        direction = self.direction
        velocity = Point(0, 0)
        if direction == DIRECTION_W:
            velocity.Y = -vel
        elif direction == DIRECTION_D:
            velocity.X = vel
        elif direction == DIRECTION_S:
            velocity.Y = vel
        elif direction == DIRECTION_A:
            velocity.X = -vel
        return velocity

    def get_map_char(self, who):
        return self.get_direction_char()

    def get_direction_char(self):
        raise NotImplementedError()


class Fruit(MySprite):
    score = 0

    def get_map_char(self, who):
        return str(self.score)


class Apple(Fruit):
    res = 'res1//apple.png'
    score = 1


class Orange(Fruit):
    res = 'res1//orange.png'
    score = 2


class Pineapple(Fruit):
    res = 'res1//pineapple.png'
    score = 3


class Strawberry(Fruit):
    res = 'res1//strawberry.png'
    score = 4


class Watermelon(Fruit):
    res = 'res1//watermelon.png'
    score = 5


class Block(Fruit):
    res = 'res1//block.png'
    score = 9
