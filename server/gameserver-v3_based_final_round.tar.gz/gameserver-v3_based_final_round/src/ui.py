import logging

import pygame as pg
from game import Game
from settings import Settings
from version import GAME_VERSION

logger = logging.getLogger(__name__)


def start_with_key():
    return Settings.get('start_with_key', False)


class UIImpl(object):
    #SCREEN_SIZE = 600
    SCREEN_SIZE = 1000
    def __init__(self):
        self.game = None
        # SCREEN size means the whole window size.
        self.SCREEN = pg.display.set_mode((UIImpl.SCREEN_SIZE, UIImpl.SCREEN_SIZE))
        # SURFACE size means the game surface size.
        self.SURFACE = pg.Surface((UIImpl.SCREEN_SIZE, UIImpl.SCREEN_SIZE))

        pg.display.set_caption(GAME_VERSION)
        self.game = Game(self.SURFACE, UIImpl.SCREEN_SIZE, UIImpl.SCREEN_SIZE)

    def loop(self):
        exit_f = False
        pg.init()
        clock = pg.time.Clock()

        while not exit_f:
            # 5 frames per seconds.
            # 由于游戏的节奏现在由前端控制，所以这边检测的频率快一点
            clock.tick(5)

            for event in pg.event.get():
                if event.type == pg.QUIT:
                    logger.debug('pg.QUIT')
                    self.game.stop(True)
                    exit_f = True
                    break

                if event.type == pg.KEYUP:
                    if event.key == pg.K_k and start_with_key() and not self.game.is_started():
                        self.game.start()
                    if event.key == pg.K_ESCAPE:
                        logger.debug('pg.K_ESCAPE')
                        self.game.stop(True)
                        exit_f = True
                        break

                # if event.type in [pg.KEYDOWN, pg.KEYUP]:
                #     self.game.on_key_event(event.type == pg.KEYDOWN, event.key)

            if exit_f:
                break
            if not self.game.update():
                break
            self.game.draw()
            self.SCREEN.blit(self.SURFACE, (0, 0))
            pg.display.flip()

        logger.info('UI thread exit')
        pg.quit()


UI = UIImpl()

