from log import logger
import asyncio
import traceback


class Message:
    def __init__(self, type, sender, data=None):
        self.type = type
        self.sender = sender
        self.data = data

    @property
    def is_closing(self):
        return self.type == '__CLOSE__'


CLOSE_MESSAGE = Message(sender=None, type='__CLOSE__')


class MessageQueue:
    def __init__(self):
        self.message_queue = []
        self.message_event = asyncio.Event()

    def push_message(self, message: Message):
        logger.debug(f'Push message:self={self}, sender={message.sender}, type={message.type}), data={message.data}')
        self.message_queue.append(message)
        self.message_event.set()

    async def fetch_message(self) -> Message:
        try:
            if len(self.message_queue) == 0:
                self.message_event.clear()
                await self.message_event.wait()
            message = self.message_queue.pop(0)
            logger.debug(
                f'Fetch message:self={self}, sender={message.sender}, type={message.type}), data={message.data}')
            return message
        except Exception:
            logger.error(traceback.format_exc())
        return CLOSE_MESSAGE

    def write_string(self, resp: str):
        self.write_message(resp.encode())

    def write_message(self, resp: bytearray or bytes):
        logger.debug(f'{self }Write response {resp}')
        self.writer.write(resp)

    @property
    def writer(self):
        return None
