from multiprocessing import Process
import time,random
import os
def piao(name):
    print(os.getppid(),os.getpid())
    print('%s is piaoing' %name)
    # time.sleep(random.randint(1,3))
    print('%s is piao end' %name)
if __name__ == '__main__':
    ghost_borns = [(5, 4), (5, 12), (10, 5), (10, 12), (2, 7), (2, 13), (13, 7), (13, 14), (4, 8), (4, 12), (8, 7),
                   (8, 13)]
    ghost_born = random.choice(ghost_borns)
    print(ghost_born[0],ghost_born[1])