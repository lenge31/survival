#!/usr/bin/env python
# -*- coding:utf-8 -*-
# ==============================================================================
#
# Copyright (c) 2019-2019
# All Rights Reserved by Thunder Software Technology Co., Ltd and its affiliates.
# You may not use, copy, distribute, modify, transmit in any form this file
# except in compliance with THUNDERSOFT in writing by applicable law.
#
# ==============================================================================

import socket
import time

import tests.simple_mock_client
import tests.simple_mock_client2
import tests.simple_mock_client3
import tests.simple_mock_client4
import tests.simple_mock_client5
import tests.simple_mock_client6
import tests.simple_mock_client7
import tests.simple_mock_client8
from multiprocessing import Process
import threading

from log import *
auth_keys=[
    "7dd486df5a714ec9a30020e452766b3e",
    "3efd4e39d0b946f59a7dd987343b9d1e",
    "678d2fb05ea14367bd7f425ddc2b5a8a",
    "2e4c0738f97546ea81a441291ff3de8d",
    "8deef46940dc4ede8a8694b02e63ce05",
    "9e462bc5bf0b4fc89d44acb21786672e",
    "43bf8c8290a84a94842d18e9d7c8f9c8",
    "12496b829e7c486fbb1a47cbb345e004",
    "0c720fe4431845a584b2f0efb6110d35",
    "ab17cbc2deca45a59c08a9c2bd5942f2",
    "feb9945c4df3434aa9b8b202e7541b1e",
    "4ab1884c6d5e442c819d1716ae4825b2"
  ]
def socketconnect(i):
    client1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client1.connect(("127.0.0.1", 9527))
    client1.send(str.encode("(" + auth_keys[i] + ")\r\n"))
    b = client1.recv(256)
    print(client1.getsockname())
    print(b.decode('utf-8'))
    # client1.sendall(str.encode("(READY)"))
    # b = client1.recv(256)
    # print(client1.getsockname())
    # print(b.decode('utf-8'))
    #client1.sendall(b"(READY)")
    #client1.sendall(str.encode("(READY)"))
    # b = client1.recv(256)
    # print(client1.getsockname())
    # print(b.decode('utf-8'))

def run(i):
    tests.simple_mock_client.run(auth_keys[i])
if __name__ == "__main__":
    threads = []
    for i in range(0, 8):
        t1 = threading.Thread(target=run, args=(i,))
        threads.append(t1)

    for t in threads:
        t.setDaemon(True)
        t.start()

    sco = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sco.connect(("127.0.0.1",9528))
    # sco.connect(("10.0.28.200",9528))
    # sco.connect(("10.0.28.151",9528))
    # sco.connect(("192.168.3.6",9528))
    sco.sendall(str.encode("AUTH 12345\r\n"))
    b = sco.recv(256)
    print(sco.getsockname())
    print(b.decode('utf-8'))
    sco.sendall(str.encode("START\r\n"))
    b = sco.recv(256)
    print(sco.getsockname())
    print(b.decode('utf-8'))
    time.sleep(10000000)
