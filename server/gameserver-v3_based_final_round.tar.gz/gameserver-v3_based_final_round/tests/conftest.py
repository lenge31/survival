import copy
import os
import random
import socket
import sys

import pytest

ROOT_DIR = os.path.dirname(os.path.dirname(__file__))
SRC_DIR = os.path.join(ROOT_DIR, 'src')
sys.path.append(SRC_DIR)

# All other project related module should import below.
# The following line should after adding SRC_DIR to PATH.
from settings import Settings


def pytest_itemcollected(item):
    # par = item.parent.obj
    # pref = par.__doc__.strip() if par.__doc__ else par.__class__.__name__
    node = item.obj
    suf = node.__doc__.strip() if node.__doc__ else node.__name__
    if node.__doc__:
        item._nodeid += ' ({})'.format(suf)


@pytest.fixture(scope='module')
def patched_settings():
    Settings['server']['port'] = random.randint(9527, 9537)
    yield Settings


@pytest.fixture()
def copyed_settings():
    yield copy.deepcopy(Settings)


# @pytest.fixture(scope='module')
# def gamemgr(patched_settings):
#     # The below line is a workaround because GMR is a singleton.
#     GMR._reset_fields()
#     GMR.run_in_new_thread()
#     GMR.wait_for_server_ready()
#     yield GMR
#     GMR.quit()
#     assert len(GMR.clients) == 0


@pytest.fixture()
def make_client_socket(gamemgr):
    def _make_client_socket():
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((gamemgr.server.ip, gamemgr.server.port))
        return s

    yield _make_client_socket
