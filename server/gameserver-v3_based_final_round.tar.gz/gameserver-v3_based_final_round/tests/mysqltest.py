
# -*- coding: utf-8 -*-
import pymysql
import demjson

class Mysql:
    def __init__(self):
        self.current_game_id = -1
        self.conn = pymysql.connect('10.0.28.187',user = "root",passwd = "123",db = "TS",port = 10051 , charset="utf8")
        self.cursor = self.conn.cursor()
    def get_gameid(self):
        return self.current_game_id
    def init_this_game(self,name:list,type:str):
        json = {"detile": [], "name": name}
        json_str = demjson.encode(json)
        sql = "insert into casions_video_game(phase,record,start_time,end_time) values ('" + type + "','" + json_str + "'," + "NOW(),'1970-01-01-00-00')"
        self.cursor.execute(sql)
        self.conn.commit()
        sql = "select game_id from casions_video_game"
        self.cursor.execute(sql)
        self.current_game_id = self.cursor.fetchall()[-1][0]
    def __make_map_one_detile(self,map:str, location:list, score:list):
        res_map = {"map": map, "location": location, "score": score}
        return res_map
    def get_conn(self):
        return self.conn
    def get_cursor(self):
        return self.cursor
    def update_game_record(self,map:str, location:list, score:list):
        res_map = self.__make_map_one_detile(map=map,location=location,score=score)
        if self.current_game_id == -1:
            return -1 # have not init game
        if self.conn == None or self.cursor == None:
            return -2 # have not connect mysql
        sql = "select record from casions_video_game where game_id = " + str(self.current_game_id)
        self.cursor.execute(sql)
        res = self.cursor.fetchall()
        json_res = demjson.decode(res[0][0])
        json_res["detile"].append(res_map)
        insert_str = demjson.encode(json_res)
        sql = "update casions_video_game set record = '" + insert_str + "'where game_id = " + str(self.current_game_id)
        self.cursor.execute(sql)
        self.conn.commit()

        return 0
    def over_game(self):
        sql = "update casions_video_game set end_time = NOW() where game_id = " + str(self.current_game_id)
        self.cursor.execute(sql)
        self.conn.commit()
        self.current_game_id = -1
        return
    def destory_game(self):
        self.cursor.close()
        self.conn.close()
        self.current_game_id = -1




name = ["team 1", "team 2", "team 3", "team 4", "team 5", "team 6", "team 7", "team 8"]
map = "saw91020G300400000093300000090000000004G00004900005405920000023990530000310000020000001000000050000400904900209004009001000000200030000003000000020010000050000000000900000405900000005000500990000009900005011022G10000000301900saw91020G300400000093300000090000000004G00004900005405920000023990530000310000020000001000000050000400904900209004009001000000200030000003000000020010000050000000000900000405900000005000500990000009900005011022G10000000301900sa091020G300400000093300000090000000004G000049000054059200000239905300003100000200000010000000500004009049002090040090010000002000300000030000000200100000500000000009000004059"
location = [0, 1, 2, 225, 226, 227, 450, 451]
score = [2, 55, 45, 67, 45, 88, 23, 100]
##############################################################################################
###   使用流程   ##############################################################################
#############################################################################################
mysql = Mysql()
# 连接数据库
mysql.connect_to_mysql()
# 初始化本局游戏
mysql.init_this_game(name=name,type="T")
# 更新游戏数据
# return：0 成功
# return：-1 未初始化游戏
# return：-2 未连接到mysql
i=0

mysql.update_game_record(map=map,location=location,score=score)
print(mysql.get_gameid())

# 当前游戏结束时调用

mysql.over_game()
# 所有游戏结束时调用
mysql.destory_game()