import socket
import threading
import time
import re
import random
from itertools import product
def playerStart(i):
    auth_keys = [
        "7dd486df5a714ec9a30020e452766b3e",
        "3efd4e39d0b946f59a7dd987343b9d1e",
        "678d2fb05ea14367bd7f425ddc2b5a8a",
        "2e4c0738f97546ea81a441291ff3de8d",
        "8deef46940dc4ede8a8694b02e63ce05",
        "9e462bc5bf0b4fc89d44acb21786672e",
        "43bf8c8290a84a94842d18e9d7c8f9c8",
        "12496b829e7c486fbb1a47cbb345e004",
        "0c720fe4431845a584b2f0efb6110d35",
        "ab17cbc2deca45a59c08a9c2bd5942f2",
        "feb9945c4df3434aa9b8b202e7541b1e",
        "4ab1884c6d5e442c819d1716ae4825b2",
        "abcdefg"
    ]
    sco = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sco.connect(("10.0.28.219", 9527))
    sco.send(str.encode("("+auth_keys[i]+")\r\n"))
    res = sco.recv(1024)
    print("user"+str(i)+res.decode("utf8"))
    res = sco.recv(1024)
    print("user" + str(i) + res.decode("utf8"))
    re_token = re.compile("\[MAP\s(?P<token>..).*\]")
    CMD_LIST = list(map(lambda x: "{}{}".format(x[0], x[1]), list(product(['a', 's', 'd', 'w'], ['v', ' ']))))

    while res.decode("utf8")[0:6]!="[START":
        time.sleep(0.2)
    sco.send(str.encode("(READY)"))

    t = threading.Thread(target=go, args=(sco, ))
    t.start()
    while True:
        data = sco.recv(1024).decode()
        print(data)
        match_token = re_token.match(data)
        if data and data == "[ERROR]":
            continue
        if data and data == "[OK]":
            continue
        if match_token:
            str_token = match_token.groupdict().get("token", "")
            send_cmd_str = "({}{})".format(str_token, random.choice(CMD_LIST))
            sco.sendall(str.encode(send_cmd_str))
            data = sco.recv(1024).decode()
            print("{} | recv {} with {}".format(sco, data, send_cmd_str))


def go(sco):
    sco.send(str.encode("(H)\r\n"))
    time.sleep(5)


def admin():
    sco = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sco.connect(("10.0.28.219", 9528))

    sco.send(str.encode("AUTH 12345\n\r"), 9528)
    res = sco.recv(1024)
    print('admin1'+res.decode("utf8"))

    sco.send(str.encode("LIST\n"), 9528)
    res = sco.recv(1024)
    print('admin2' + res.decode("utf8"))

    time.sleep(1)

    sco.send(str.encode("START\n"), 9528)
    res = sco.recv(1024)
    print('admin4' + res.decode("utf8"))

    while True:
        sco.send(str.encode("STATUS\n"), 9528)
        res = sco.recv(1024)
        print('admin3' + res.decode("utf8"))
        time.sleep(1)


def main():
    for i in range(0, 13):
        t = threading.Thread(target=playerStart, args=(i,))
        t.start()
        time.sleep(0.5)

    time.sleep(1)
    t = threading.Thread(target=admin)
    t.start()



if __name__ == "__main__":
    main()