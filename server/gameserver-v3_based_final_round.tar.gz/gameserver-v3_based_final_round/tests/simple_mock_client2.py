#!/usr/bin/env python
# -*- coding:utf-8 -*-
# ==============================================================================
#
# Copyright (c) 2019-2019
# All Rights Reserved by Thunder Software Technology Co., Ltd and its affiliates.
# You may not use, copy, distribute, modify, transmit in any form this file
# except in compliance with THUNDERSOFT in writing by applicable law.
#
# ==============================================================================

import re
import os
import sys
import time
import json
import types
import socket
import random
import argparse
import selectors
import traceback

from datetime import datetime

# from multiprocessing import Process

# sco = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# sco.connect(("10.0.28.98",9528))
# sco.sendall(str.encode("START"))

class Client(object):
    def __init__(self,connid,SERVER_ADDR,my_timeout=9000):
        self.connid = connid
        self.server_addr = SERVER_ADDR
        self.my_timeout = my_timeout
        self.sco = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sco.connect(SERVER_ADDR)
        self.sco.settimeout(my_timeout)
    def RunCase(self,key_val):
        print("Test Case By Default")
        self.sco.sendall(str.encode("({})".format(key_val)))
        data = self.sco.recv(1024)
        print(data)
    def close(self):
        self.sco.close()

class ClientHello(Client):
    def __init__(self,connid,SERVER_ADDR,my_timeout=9000):
        super().__init__(connid,SERVER_ADDR,my_timeout)
    def RunRound(self,play_num):
        print("RunRound for play : {}".format(play_num))
        self.sco.sendall(str.encode("(READY)"))
        print("send (READY)")
        re_gameover = re.compile("\[GAMEOVER\s(?P<round>\d+)\s(?P<score>\d+)\]")
        re_token = re.compile("\[(?P<token>.).*\]")
        CMD_LIST = ["mv","hi","hello","what","mv"]
        str_token = ""
        self.sco.sendall(str.encode("0mv"))
        while True:
            print("while socket recv")
            data = self.sco.recv(1024).decode()
            print(data)
            match_gameover = re_gameover.match(data)
            if match_gameover:
                print(re_gameover.groupdict())
                # self.sco.sendall(b"(QUIT)")
                self.sco.sendall(str.encode("(QUIT)"))
                print("send (QUIT) by : {}".format(play_num))
                break
            if data and data == "[ERROR]":
                continue
            if data and data == "[OK]":
                continue
            match_token = re_token.match(data)
            if match_token:
                str_token = match_token.groupdict().get("token","")
                send_cmd_str = "({}{})".format(str_token,random.choice(CMD_LIST))
                self.sco.sendall(str.encode(send_cmd_str))
                print("send {} by : {}".format(send_cmd_str,play_num))
                data = self.sco.recv(1024).decode()
                print("recv {} with {}".format(data,send_cmd_str))
    def RunCase(self,key_val):
        print("Test Case By client {}".format(self.connid))
        login_retry = 0
        data = "[ERROR]"
        while True:
            if login_retry == 5:
                break
            self.sco.sendall(str.encode("({})".format(key_val)))
            print("send 1 ({})".format(key_val))
            data = self.sco.recv(1024)
            print(data)
            str_data = data.decode()
            if str_data and str_data == "[OK]":
                break
            login_retry = login_retry + 1
        if not str_data or str_data != "[OK]":
            return
        int_player = -1
        # re_start = re.compile("\[START\s(?P<id>.*)\]")
        re_start = re.compile("\[START\s(?P<i>.*)\s(?P<m>.*)")
        # sco = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # sco.connect(("127.0.0.1", 9528))
        # sco.sendall(str.encode("AUTH 12345\r\n"))
        # b = sco.recv(256)
        # print(sco.getsockname())
        # print(b.decode('utf-8'))
        # sco.sendall(str.encode("START\r\n"))
        # b = sco.recv(256)
        # print(sco.getsockname())
        # print(b.decode('utf-8'))
        while True:
            # self.sco.sendall(b"(H)")
            self.sco.sendall(str.encode("(H)"))
            print("send 2 (H) by : {}".format(key_val))
            data = self.sco.recv(1024).decode()
            print(data)
            if data and data == "[ROUNDOVER]":
                break
            match_start = re_start.match(data)
            print(match_start)
            if match_start:
                int_player = int(match_start.groupdict().get("i","-1"))
                # self.sco.sendall(b"(READY)")
                # self.sco.sendall(str.encode("(READY)"))
                # print("send (READY)")
                self.RunRound(int_player)
            time.sleep(5)

def one_client_test(num,server_addr,auth_key):
    c = ClientHello(num,server_addr)
    print("{} | ClientHello".format(num))
    c.RunCase(auth_key)
    print("{} | c.RunCase by : {}".format(num,auth_key))
    c.close()
    print("{} | c.close".format(num))

def run():
    parser = argparse.ArgumentParser(
        prog="python {}".format(sys.argv[0]),
        description='Thundersoft Technology Games.',
        epilog='Copyright (c) 2019-2019 All Rights Reserved by Thunder Software Technology Co.')
    parser.add_argument('--host', action='store', default="127.0.0.1", help='')
    # parser.add_argument('--host', action='store', default="10.0.28.200", help='')
    # parser.add_argument('--host', action='store', default="10.0.28.151", help='')
    # parser.add_argument('--host', action='store', default="192.168.3.6", help='')
    parser.add_argument('--conf', action='store', default="default.json", help='')
    ARGS = parser.parse_args()
    config_json = {}
    if os.path.exists(ARGS.conf):
        with open(ARGS.conf) as f:
            config_json = json.load(f)
    #game_default_port = 9526
    game_default_port = 9527
    game_port = config_json.get("server",{"port":game_default_port}).get("port",game_default_port)
    auth_list = config_json.get("auth_keys",["3efd4e39d0b946f59a7dd987343b9d1e"])
    server_addr = (ARGS.host, int(game_port))
    print(server_addr)
    one_client_test(datetime.now().strftime('%y%m%d%H%M%S'),server_addr,random.choice(auth_list))
