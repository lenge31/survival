#!/usr/bin/env python
# -*- coding:utf-8 -*-
# ==============================================================================
#
# Copyright (c) 2019-2019
# All Rights Reserved by Thunder Software Technology Co., Ltd and its affiliates.
# You may not use, copy, distribute, modify, transmit in any form this file
# except in compliance with THUNDERSOFT in writing by applicable law.
#
# ==============================================================================

import re
import os
import sys
import time
import json
import types
import socket
import random
import argparse
import selectors
import traceback

from datetime import datetime
from itertools import product
from multiprocessing import Pool, TimeoutError

# sco = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# sco.connect(("10.0.28.98",9528))
# sco.sendall(str.encode("START"))

def print2file(connid,tuichu,message):
    with open("a_simple_client.log","a+") as f:
        print("{} | {} | {}".format(connid,tuichu,message),file=f)

class Client(object):
    def __init__(self,connid,SERVER_ADDR,tuichu=0,my_timeout=9000):
        self.connid = connid
        self.server_addr = SERVER_ADDR
        self.my_timeout = my_timeout
        self.sco = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sco.connect(SERVER_ADDR)
        self.sco.settimeout(my_timeout)
        self.tuichu = tuichu
    def RunCase(self,key_val):
        print2file(self.connid,self.tuichu,"Test Case By Default")
        self.sco.sendall(str.encode("({})".format(key_val)))
        data = self.sco.recv(1024)
        print2file(self.connid,self.tuichu,data)
    def guyituichu(self,status_num):
        if self.tuichu == status_num:
            print2file(self.connid,status_num,"{} ... ... ... Gu Yi Tui Chu !!!".format(status_num))
            sys.exit(1)
    def close(self):
        self.sco.close()

class ClientHello(Client):
    def __init__(self,connid,SERVER_ADDR,tuichu=0,my_timeout=9000):
        super().__init__(connid,SERVER_ADDR,tuichu,my_timeout)
    def RunRound(self,play_num):
        self.guyituichu(5)
        print2file(self.connid,self.tuichu,"RunRound for play : {}".format(play_num))
        self.sco.sendall(str.encode("(READY)"))
        print2file(self.connid,self.tuichu,"send (READY)")
        self.guyituichu(6)
        # re_gameover = re.compile("\[GAMEOVER\s(?P<round>\d+)\s(?P<score>\d+)\]")
        re_gameover = re.compile("\[GAMEOVER\s(?P<round>.*)\]")
        re_token = re.compile("\[MAP\s(?P<token>..).*\]")
        CMD_LIST = list(map(lambda x:"{}{}".format(x[0],x[1]),list(product(['a','s','d','w'],['v',' ']))))
        str_token = ""
        # self.sco.sendall(str.encode("0mv"))
        self.guyituichu(7)
        while True:
            data = self.sco.recv(1024).decode()
            match_gameover = re_gameover.match(data)
            if match_gameover:
                # self.sco.sendall(b"(QUIT)")
                self.guyituichu(8)
                self.sco.sendall(str.encode("(QUIT)"))
                print2file(self.connid,self.tuichu,"send (QUIT) by : {}".format(play_num))
                break
            if data and data == "[ERROR]":
                continue
            if data and data == "[OK]":
                continue
            match_token = re_token.match(data)
            if match_token:
                str_token = match_token.groupdict().get("token","")
                send_cmd_str = "({}{})".format(str_token,random.choice(CMD_LIST))
                self.sco.sendall(str.encode(send_cmd_str))
                data = self.sco.recv(1024).decode()
                print2file(self.connid,self.tuichu,"{} | recv {} with {}".format(play_num,data,send_cmd_str))
    def RunCase(self,key_val):
        print2file(self.connid,self.tuichu,"Test Case By client {}".format(self.connid))
        login_retry = 0
        data = "[ERROR]"
        self.guyituichu(1)
        while True:
            if login_retry == 5:
                break
            self.sco.sendall(str.encode("({})".format(key_val)))
            print2file(self.connid,self.tuichu,"send ({})".format(key_val))
            data = self.sco.recv(1024)
            print2file(self.connid,self.tuichu,data)
            str_data = data.decode()
            if str_data and str_data == "[OK]":
                break
            login_retry = login_retry + 1
        self.guyituichu(2)
        if not str_data or str_data != "[OK]":
            return
        int_player = -1
        re_start0 = re.compile("\[START\s(?P<id>\d+)\s.*\]")
        re_start1 = re.compile("\[ERROR\]\[START\s(?P<id>\d+)\s.*\]")
        # re_start = re.compile("START\s(?P<i>.*)\s(?P<m>.*)")
        while True:
            # self.sco.sendall(b"(H)")
            self.guyituichu(3)
            self.sco.sendall(str.encode("(H)"))
            self.guyituichu(4)
            data = self.sco.recv(1024).decode()
            print2file(self.connid,self.tuichu,"wait next round......recv {} with send (H) by : {}".format(data,key_val))
            if data and data == "[ROUNDOVER]":
                break
            if data and data == "[ERROR][ROUNDOVER]":
                break
            match_start0 = re_start0.match(data)
            if match_start0:
                int_player = int(match_start0.groupdict().get("id","-1"))
            match_start1 = re_start1.match(data)
            if match_start1:
                int_player = int(match_start1.groupdict().get("id","-1"))
            if match_start0 or match_start1:
                self.RunRound(int_player)
            time.sleep(5)

def one_client_test(num,server_addr,auth_key):
    try:
        tuichu = random.choice([0,1,2,3,4,5,6,7,8,0,0,0,0,0,0,0,0])
        c = ClientHello(num,server_addr,tuichu=tuichu)
        print2file(num,tuichu,"ClientHello")
        c.RunCase(auth_key)
        print2file(num,tuichu,"c.RunCase by : {}".format(auth_key))
        c.close()
        print2file(num,tuichu,"c.close")
    except Exception as e:
        print(traceback.format_exc())

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog="python {}".format(sys.argv[0]),
        description='Thundersoft Technology Games.',
        epilog='Copyright (c) 2019-2019 All Rights Reserved by Thunder Software Technology Co.')
    # parser.add_argument('--host', action='store', default="10.0.28.98", help='')
    parser.add_argument('--host', action='store', default="127.0.0.1", help='')
    # parser.add_argument('--host', action='store', default="10.0.28.197", help='')
    # parser.add_argument('--host', action='store', default="10.0.28.200", help='')
    # parser.add_argument('--host', action='store', default="10.0.28.151", help='')
    # parser.add_argument('--host', action='store', default="192.168.3.6", help='')
    parser.add_argument('--conf', action='store', default="default.json", help='')
    parser.add_argument('games', metavar='games',help='game number')
    try:
        ARGS = parser.parse_args()
        config_json = {}
        if os.path.exists(ARGS.conf):
            with open(ARGS.conf) as f:
                config_json = json.load(f)
        # game_default_port = 9526
        game_default_port = 9527
        game_port = config_json.get("server",{"port":game_default_port}).get("port",game_default_port)
        auth_list = config_json.get("auth_keys",["11111","22222","33333","44444","55555","66666","77777","88888","99999","00000"])
        server_addr = (ARGS.host, int(game_port))
        # one_client_test(datetime.now().strftime('%y%m%d%H%M%S'),server_addr,random.choice(auth_list))
        max_client = 100
        max_client = int(ARGS.games)
        pool = Pool(processes=max_client)
        result = []
        for i in range(0,max_client):
            cid = datetime.now().strftime('%y%m%d%H%M%S%f')
            # aid = random.choice(auth_list)
            aid = "test_auth_{}".format(i)
            ar = pool.apply_async(one_client_test, (cid,server_addr,aid))
            result.append(ar)
            if i%9 == 0:
                ar = pool.apply_async(one_client_test, (cid,server_addr,aid))
                result.append(ar)
        for r in result:
            r.wait(60*60)
    except Exception as e:
        print(traceback.format_exc())