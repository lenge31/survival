#!/usr/bin/env python
# -*- coding:utf-8 -*-
# ==============================================================================
#
# Copyright (c) 2019-2019
# All Rights Reserved by Thunder Software Technology Co., Ltd and its affiliates.
# You may not use, copy, distribute, modify, transmit in any form this file
# except in compliance with THUNDERSOFT in writing by applicable law.
#
# ==============================================================================
import argparse
import asyncio
import sys, os
import traceback
from asyncio.subprocess import PIPE


class GameProtocol(asyncio.SubprocessProtocol):
    def __init__(self, event: asyncio.Event):
        self.event = event
        self._message = []

    def pipe_data_received(self, fd, data):
        print(f'Get data from backend {data}', file=sys.stderr)
        self.parse_backend_data(data)

    def process_exited(self):
        pass

    def parse_backend_data(self, data):
        self._message.append(data)
        self.event.set()

    async def get_message(self):
        while True:
            if len(self._message):
                return self._message.pop(0).decode().strip()
            self.event.clear()
            await self.event.wait()


async def test2():
    try:
        # Start game process
        loop = asyncio.get_running_loop()
        msg_event = asyncio.Event()

        print(f'Launch test', file=sys.stderr)
        transport, protocol = await loop.subprocess_exec(
            lambda: GameProtocol(msg_event),
            executable, arguments, stdin=PIPE, stdout=PIPE, stderr=None)

        # Get handle for writing
        writer = transport.get_pipe_transport(0)
        message = 'COUNT 11\n'.encode()
        writer.write(message)

        while True:
            message = await protocol.get_message()
            print(f'Get message {message}', file=sys.stderr)
            if message.startswith('GAMEOVER '):
                break
            writer.write(b'CONTROL XX  wvsvdvavw s d a \n')

    except Exception:
        print(traceback.format_exc(), file=sys.stderr)


async def test1():
    try:
        # Start game process
        print(f'Launch test', file=sys.stderr)
        proc = await asyncio.create_subprocess_exec(
            executable, arguments, stdin=PIPE, stdout=PIPE, stderr=None)

        # Get handle for writing
        message = b'COUNT 11\n'
        proc.stdin.write(message)
        await proc.stdin.drain()

        while True:
            line = await proc.stdout.readline()
            message = line.decode().strip()
            print(f'Get message {message}', file=sys.stderr)
            if message.startswith('GAMEOVER '):
                break
            if message.startswith('SCORE '):
                proc.stdin.write(b'CONTROL XX  wvsvdvavw s d a \n')

    except Exception:
        print(traceback.format_exc(), file=sys.stderr)


executable = sys.executable

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog="python {}".format(sys.argv[0]),
        description='Thundersoft Technology Games.',
        epilog='Copyright (c) 2019-2019 All Rights Reserved by Thunder Software Technology Co.')
    parser.add_argument('--fake', action='store', default=False, help='')
    ARGS = parser.parse_args()
    if not ARGS.fake:
        os.chdir('../src')
        arguments = 'main.py'
    else:
        os.chdir('../tests')
        arguments = 'test_game.py'

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test1())
    loop.run_until_complete(test2())
