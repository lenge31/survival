import re
import sys
from io import BufferedReader, BufferedWriter

from log import logger


def read_message(buffer: BufferedReader):
    message = ''
    while True:
        line = buffer.readline()
        try:
            message = line.decode().strip()
            print(f'Message received: {message}', file=sys.stderr)
            break
        except UnicodeEncodeError:
            print(f'Invalid Message received: {line}', file=sys.stderr)
            continue
    return message


def write_message(buffer: BufferedWriter, message):
    print(f'To send message: {message}', file=sys.stderr)
    line = message.encode()
    buffer.write(line + b'\n')
    buffer.flush()


inbuf = sys.stdin.buffer
outbuf = sys.stdout.buffer

PAT_PLAYERS = re.compile(r'COUNT (\d+)')
players = 0
while True:
    message = read_message(inbuf)
    if not message:
        continue
    m = PAT_PLAYERS.match(message)
    if not m:
        print('PLAYER_COUNT message wrong', file=sys.stderr)
    else:
        players = int(m.group(1))
        break

print(f'There are {players} players', file=sys.stderr)

map_data = 'MAP ' + '0' * 225
location_data = 'LOCATION 1 2 3 4 5 6 7 8 9 10 11'
score_data = 'SCORE 1 2 3 4 5 6 7 8 9 10 11'

for i in range(10):
    write_message(buffer=outbuf, message=map_data)
    print(f'sent map message {map_data}', file=sys.stderr)
    write_message(buffer=outbuf, message=location_data)
    print(f'sent location message {location_data}', file=sys.stderr)
    write_message(buffer=outbuf, message=score_data)
    print(f'sent score message {score_data}', file=sys.stderr)
    control = read_message(inbuf)
    print(f'receive message {control}', file=sys.stderr)

game_over = 'GAMEOVER 10 20 30 40 50 60 70 80 90 100 110'
write_message(buffer=outbuf, message=game_over)
