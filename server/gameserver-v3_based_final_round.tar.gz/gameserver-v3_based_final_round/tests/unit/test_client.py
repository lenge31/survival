import struct
from uuid import uuid4

from iclientmgr import *


class TestClient:
    def test_handshake_1(self, gamemgr, make_client_socket, copyed_settings):
        """
        Handshake with none exist key
        """
        # Clean all client keys.
        copyed_settings['client'] = []

        key = uuid4().hex
        data = struct.pack('<HI{}s'.format(len(key)), 0, len(key), bytearray(key, 'utf8'))
        s = make_client_socket()
        s.sendall(data)

        data = s.recv(MSG_TYPE_LEN)
        msg_type = struct.unpack('<H', data)
        assert msg_type is not None
        assert msg_type[0] == get_resp_msg_type(MSG_TYPE_HANDSHAKE)

        data = s.recv(ERR_CODE_LEN)
        err = struct.unpack('<H', data)
        assert err is not None
        assert err[0] == ERR_KEY

        data = s.recv(DATA_LEN)
        data_len = struct.unpack('<I', data)
        assert data_len is not None
        assert data_len[0] == MAP_DATA_LEN

        data = s.recv(MAP_DATA_LEN)
        map_data = struct.unpack('<II', data)
        assert map_data is not None
        assert map_data[0] == copyed_settings['map']['x']
        assert map_data[1] == copyed_settings['map']['y']

    def test_handshake_2(self, gamemgr, make_client_socket, copyed_settings):
        """
        Handshake with error key len
        """
        key = uuid4().hex[:20]
        data = struct.pack('<HI{}s'.format(len(key)), 0, len(key), bytearray(key, 'utf8'))
        s = make_client_socket()
        s.sendall(data)

        data = s.recv(MSG_TYPE_LEN)
        msg_type = struct.unpack('<H', data)
        assert msg_type is not None
        assert msg_type[0] == get_resp_msg_type(MSG_TYPE_HANDSHAKE)

        data = s.recv(ERR_CODE_LEN)
        err = struct.unpack('<H', data)
        assert err is not None
        assert err[0] == ERR_DATA_FORMAT

        data = s.recv(DATA_LEN)
        data_len = struct.unpack('<I', data)
        assert data_len is not None
        assert data_len[0] == MAP_DATA_LEN

        data = s.recv(MAP_DATA_LEN)
        map_data = struct.unpack('<II', data)
        assert map_data is not None
        assert map_data[0] == copyed_settings['map']['x']
        assert map_data[1] == copyed_settings['map']['y']

    # TODO: add more test cases for verifying the interactions between client
    #  and server.
