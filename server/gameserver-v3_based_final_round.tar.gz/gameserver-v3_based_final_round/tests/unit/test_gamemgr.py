import time


def test_client_connection(gamemgr, make_client_socket):
    clients = []
    for i in range(50):
        s = make_client_socket()
        clients.append(s)

    time.sleep(1)

    assert len(gamemgr.clients) == len(clients)
