from settings import SettingMgr


class Dummy(object):
    pass


def test_singleton():
    s1 = SettingMgr()
    s2 = SettingMgr()
    assert s1 == s2
    assert id(s1) == id(s2)


def test_none_singleton():
    d1 = Dummy()
    d2 = Dummy()
    assert d1 != d2
    assert id(d1) != id(d2)
